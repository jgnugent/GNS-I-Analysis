jgn_survfit_summary <- function(data, term = 'Survival', abbreviations = NA, round_digits = 0, p_accuracy = 0.001, prevalence_accuracy = 0.1, print = TRUE, include_overall = TRUE, sort_rmean = TRUE, ...){
	survfit_object <- (summary(data)$table)

	variable_label <- ''

	test_for_trend <- FALSE

	if(is_empty(names(survfit_object))){
		parent <- data %>% insight::get_data()

		multi <- TRUE

		include_overall_row <- include_overall

		survfit_object <- (summary(data)$table) %>%
			as_tibble(rownames = 'Level') %>%
			separate_wider_delim(Level, delim = '=', names = c('Variable', 'Level'))

		if(data$type == 'right'){
			logrank_p <- (data %>% surv_pvalue())$pval %>% as.numeric()
		} else {
			logrank_p <- coxph(data$call$formula %>% as.formula(), data = parent) %>%
				glance() %>%
				pull(p.value.sc) %>%
				unname()
		}

		if(data$type == 'right' & survfit_object %>% nrow() > 2){
			test_for_trend = TRUE
			test_for_trend_p <- (data %>% surv_pvalue(test.for.trend = TRUE))$pval %>% as.numeric()
		}

		variable <- survfit_object %>% pull(Variable) %>% unique()
		variable_label <- parent %>% pull(variable) %>% var_label()

		survfit_object <- survfit_object %>% rename(
			!!variable_label := 'Level',
		)
	} else {
		multi <- FALSE

		include_overall_row <- FALSE

		survfit_object <- survfit_object %>%
			t() %>%
			as_tibble()
	}

	if(!is.na(abbreviations)){
		#caption = paste0('<em><strong>Abbreviations</strong>: se = Standard Error; CI = Confidence Interval; NA = Not Available; ', abbreviations,'.</em>')
		caption = paste0('<em><strong>Abbreviations</strong>: CI = Confidence Interval; NA = Not Available; ', abbreviations,'.</em>')
	} else {
		#caption = '<em><strong>Abbreviations</strong>: se = Standard Error; CI = Confidence Interval; NA = Not Available.</em>'
		caption = '<em><strong>Abbreviations</strong>: CI = Confidence Interval; NA = Not Available.</em>'
	}

	if(sort_rmean){
		survfit_object <- survfit_object %>%
			arrange(rmean, median)
	}

	output <- survfit_object %>%
		mutate(
			events = glue::glue(
				'{events} ({scales::percent(events/records, accuracy = prevalence_accuracy)})'
			),
			ci_lb = rmean - qnorm(0.975)*`se(rmean)`,
			ci_ub = rmean + qnorm(0.975)*`se(rmean)`
		) %>%
		mutate(
			across(
				c(rmean, `se(rmean)`, ci_lb, ci_ub, median, `0.95LCL`, `0.95UCL`),
				~format(.x %>% round(digits = round_digits), big.mark = ',', nsmall = round_digits)
			)
		) %>%
		mutate(
			!!paste0('Mean ', term, ' (se)') := paste0(rmean, ' (', `se(rmean)`, ')'),
			!!paste0('Mean ', term, ' (95% CI)') := paste0(rmean, ' (', ci_lb, ' – ', ci_ub, ')'),
			!!paste0('Median ', term, ' (95% CI)') := paste0(median, ' (', `0.95LCL`, ' – ', `0.95UCL`, ')')
		) %>%
		mutate_if(is.character, str_squish) %>%
		rename(
			'n' = records,
			'Starting $n$' = n.start,
			'Max $n$' = n.max,
			'Events (%)' = events
		) %>%
		select(
			one_of(variable_label),
			'n',
			# 'Starting $n$',
			# 'Max $n$',
			'Events (%)',
			#paste0('Mean ', term, ' (se)'),
			paste0('Mean ', term, ' (95% CI)'),
			paste0('Median ', term, ' (95% CI)'),
		)

	if(include_overall_row){
		overall <- with(
			data %>% insight::get_data(),
			paste0(data %>% insight::find_formula() %>% format() %>% pluck(1), '1') %>% formula()
		) %>%
			survfit() %>%
			jgn_survfit_summary(print = FALSE, include_overall = FALSE, round_digits = round_digits) %>%
			bind_cols(name = 'Overall') %>%
			relocate(name) %>%
			rename(!!names(output)[1] := name)

		output <- output %>%
			bind_rows(
				overall
			)
	}

	if(multi){
		output <- output %>%
			gdata::cbindX(
				tribble(
					~'Log-Rank p-value',
					logrank_p
				)
			)

		logrank_p_col <- which(colnames(output) == 'Log-Rank p-value')

		if(test_for_trend){
			output <- output %>%
				gdata::cbindX(
					tribble(
						~'Test for Trend p-value',
						test_for_trend_p,
					)
				)
			test_for_trend_p_col <- which(colnames(output) == 'Test for Trend p-value')
		}
	}

	output <- output %>%
		as_tibble() %>%
		mutate(
			across(
				one_of('Mean Survival (95% CI)', 'Median Survival (95% CI)'),
				~(
					.x %>%
						str_remove_all(' ') %>%
						str_replace('\\(', ' \\(') %>%
						str_replace('–', ' – ')
				)
			),
			across(
				where(is.character),
				~str_remove(.x, 'NA \\(NA – NA\\)')
			),
			across(
				matches('p.value'),
				~case_when(
					!is.na(.x) ~ .x %>% scales::pvalue(p_accuracy)
				)
			)
		)

	if(print){
		if('Overall' %in% (output %>% pull(1))){
			overall_row <- which(output %>% pull(1) =='Overall')
		}

		output <- output %>%
			print_kable(...) %>%
			opt_footnote_marks(marks = 'extended') %>%
			tab_footnote(
				footnote = gt::html(caption)
			)

		if(multi){
			output <- output %>%
				tab_style(
					style = cell_text(decorate = 'underline'),
					locations = cells_body(
						columns = 1
					)
				) %>%
				tab_style(
					style = cell_text(weight = 'bold'),
					locations = cells_body(
						columns = `Log-Rank p-value`,
						rows = `Log-Rank p-value` %>% str_remove('>') %>% str_remove('<') %>% as.numeric() < 0.05
					)
				)

			if(exists('overall_row')){
				output <- output %>%
					tab_style(
						style = cell_text(weight = 'bold'),
						locations = cells_body(
							rows = overall_row
						)
					)
			}
		}

		if(test_for_trend){
			output <- output %>%
				tab_style(
					style = cell_text(weight = 'bold'),
					locations = cells_body(
						columns = `Test for Trend p-value`,
						rows = `Test for Trend p-value` %>% str_remove('>') %>% str_remove('<') %>% as.numeric() < 0.05
					)
				)
		}
	}

	return(output)
}

jgn_ggsurvplot_pval <- function(data, p_accuracy = 0.001){
  p_val <- coxph(data$call$formula %>% as.formula(), data = get(data$call$data)) %>%
    glance() %>%
    pull(p.value.sc) %>%
    unname() %>%
    scales::pvalue(accuracy = p_accuracy, prefix = c('p < ', 'p = ', 'p > '))

  return(p_val)
}

jgn_ggsurvplot_trend_pval <- function(data, p_accuracy = 0.001){
  (data %>% surv_pvalue(test.for.trend = TRUE))$pval %>%
    scales::pvalue(prefix = c('p < ', 'p = ', 'p > ')) %>%
    return()
}

jgn_tvc_test <- function(model){
	variables <- model %>% find_predictors() %>% pluck(1)
	base_terms <- model %>% tidy() %>% pull(term)
	results <- tibble()

	walk(
		variables,
		~(
			results <<- rstpm2::cox.tvc(model, var = .x) %>%
				tidy(conf.int = TRUE) %>%
				filter(!term %in% base_terms) %>%
				bind_rows(results, .)
		),
		.progress = TRUE
	)

	results %>%
		print_kable() %>%
		return()
}

jgn_walk_cox_functional <- function(model, point_color = '#56B4E9', vars_to_exclude = NULL){
	walk(
		model %>%
			get_data() %>%
			select(
				(model$terms %>% attributes())$dataClasses[-1] %>%
					as_tibble(rownames = 'rowname') %>%
					filter(value == 'numeric') %>%
					pull(rowname)
			) %>%
			select(
				where(~all(. > 0)),
				-one_of(vars_to_exclude)
			),
		~(
			ggcoxfunctional(
				coxph(
					Surv(model$y[,1], model$y[,2]) ~
						I(.x^3) + I(.x^2) + .x + sqrt(.x) + log(.x) + I(1/sqrt(.x)) + I(1/.x) + I(1/(.x^2)) + I(1/(.x^3)),
					data = model$call$data %>% get()
				),
				ggtheme = theme_jgn(),
				point.col = point_color,
				#point.alpha = 0.5,
				caption = var_label(.x)
			)
		) %>% print(),
		.progress = TRUE
	)
}

arrange_factor_rmean <- function(os_strata_object){
	arranged_levels <- (summary(os_strata_object)$table) %>%
		as_tibble(rownames = 'Level') %>%
		separate_wider_delim(Level, delim = '=', names = c('Variable', 'Level')) %>%
		arrange(rmean, median) %>%
		pull(Level)

	factor_var <- os_strata_object %>%
		find_predictors() %>%
		pluck(1)

	data_object <- os_strata_object$call$data %>%
		as.character()

	updated_data <- os_strata_object %>%
		get_data() %>%
		mutate(
			!!eval(factor_var) := get(factor_var) %>% as.character() %>% factor(c(arranged_levels))
		) %>%
		copy_labels_from(os_strata_object %>% get_data())

	assign(data_object, updated_data, envir = globalenv())

	return(os_strata_object)
}
