seaborn_palettes <- list(
	deep = c('#4C72B0','#55A868','#C44E52','#8172B2','#CCB974','#64B5CD'),
	muted = c('#4878CF','#6ACC65','#D65F5F','#B47CC7','#C4AD66','#77BEDB'),
	pastel = c('#92C6FF','#97F0AA','#FF9F9A','#D0BBFF','#FFFEA3','#B0E0E6'),
	bright = c('#003FFF','#03ED3A','#E8000B','#8A2BE2','#FFC400','#00D7FF'),
	dark = c('#001C7F','#017517','#8C0900','#7600A1','#B8860B','#006374'),
	colorblind = c('#0072B2','#009E73','#D55E00','#CC79A7','#F0E442','#56B4E9')
)

seaborn_pal <- function(palette = 'deep', alpha = 1, reverse = FALSE, ...){
	pal <- seaborn_palettes[[palette]]

	if(reverse){
		pal <- rev(pal)
	}

	colorRampPalette(pal, ...)
}

show_seaborn_palettes <- function(palette = NULL){
	if(is_empty(palette)){
		scales::show_col(seaborn_pal('deep')(6))
		scales::show_col(seaborn_pal('muted')(6))
		scales::show_col(seaborn_pal('pastel')(6))
		scales::show_col(seaborn_pal('bright')(6))
		scales::show_col(seaborn_pal('dark')(6))
		scales::show_col(seaborn_pal('colorblind')(6))
	} else{
		scales::show_col(seaborn_pal(palette)(6))
	}
}

scale_color_seaborn <- function(palette = 'deep', discrete = TRUE, reverse = FALSE, ...){
	pal <- seaborn_pal(palette = palette, reverse = reverse)

	if(discrete){
		discrete_scale('colour', paste0('seaborn_', palette), palette = pal, ...)
	} else {
		scale_color_gradientn(colours = pal(256), ...)
	}
}

scale_fill_seaborn <- function(palette = 'deep', discrete = TRUE, reverse = FALSE, ...){
	pal <- seaborn_pal(palette = palette, reverse = reverse)

	if(discrete){
		discrete_scale('fill', paste0('seaborn_', palette), palette = pal, ...)
	} else {
		scale_fill_gradientn(colours = pal(256), ...)
	}
}

jggroc <- function(data, cut_by = 25, round_digits = 3, ...){
	doParallel::registerDoParallel()
	auroc_cis <- data %>%
		ci.se(specificities = seq(0, 1, l = cut_by), parallel = TRUE, ...) %>%
		as.data.frame() %>%
		as_tibble(rownames = 'x') %>%
		mutate(x = x %>% as.numeric()) %>%
		rename(
			lower_bound = `2.5%`,
			median = `50%`,
			upper_bound = `97.5%`
		)

	auroc_points <- bind_cols(
		Sensitivity = data$sensitivities,
		Specificity = data$specificities
	) %>%
		mutate(
			`1-Specificity` = 1-Specificity
		)

	auc_ci_print <- data$ci %>%
		as.numeric() %>%
		as_tibble() %>%
		pull(value) %>%
		sprintf(paste0('%0.', round_digits, 'f'), .)

	ggroc(
		data = data,
		legacy.axes = TRUE
	)  +
		geom_abline(
			intercept = 0,
			slope = 1,
			color = pal_nejm()(2)[1],
			linetype = 'longdash'
		) +
		geom_ribbon(
			data = auroc_cis,
			aes(
				x = 1-x,
				ymin = lower_bound,
				ymax = upper_bound
			),
			fill = pal_nejm()(2)[2],
			color = 'gray',
			alpha = 0.2
		) +
		# geom_point(
		# 	inherit.aes =  FALSE,
		# 	data = auroc_points,
		# 	aes(
		# 		x = `1-Specificity`,
		# 		y = Sensitivity
		# 	)
		# ) +
		theme_jgn() +
		labs(
			x = '1-Specificity',
			y = 'Sensitivity'
		) +
		coord_equal(
			ylim = c(0, 1),
			xlim = c(0, 1)
		) +
		annotate(
			geom = 'text',
			x = 0.99,
			y = 0.06,
			label = paste0('AUROC: ', auc_ci_print[2], ' (', auc_ci_print[1], ' – ', auc_ci_print[3], ')'),
			family = font,
			size = 5,
			hjust = 1
		)
}

jggprc <- function(data, replicates = 2000, cut_by = 100, ci_level = 0.95){
	librarian::shelf(
		boot,
		precrec
	)

	labels <- data$response
	predictions <- data$predictor

	set.seed(123)

	# Create evaluation object
	# mode = 'rocprc' calculates both ROC and PRC curves
	sscurves <- evalmod(
		scores = predictions,
		labels = labels,
		mode = 'rocprc'
	)

	# Extract AUC values
	auc_values <- precrec::auc(sscurves)

	# Get AUPRC (second row in aucs)
	auprc <- auc_values$aucs[2]  # PRC AUC
	auroc <- auc_values$aucs[1]  # ROC AUC

	# list(
	# 	auprc = auprc,
	# 	auroc = auroc,
	# 	prevalence = mean(labels),
	# 	eval_obj = sscurves
	# )

	original_auprc <- auprc

	# Bootstrap function
	boot_auprc <- function(data, indices) {
		d <- data[indices, ]
		sscurves <- evalmod(
			scores = d$pred,
			labels = d$label,
			mode = 'rocprc'
		)
		auc_val <- precrec::auc(sscurves)
		return(auc_val$aucs[2])  # Return AUPRC
	}

	# Prepare data for bootstrap
	boot_data <- data.frame(label = labels, pred = predictions)

	# Perform bootstrap
	boot_results <- boot(
		data = boot_data,
		statistic = boot_auprc,
		R = replicates
	)

	# Calculate confidence interval
	alpha <- 1 - ci_level
	ci <- boot.ci(boot_results, conf = ci_level, type = 'perc')

	# Alternative: manual percentile CI
	boot_auprcs <- boot_results$t
	ci_lower <- quantile(boot_auprcs, alpha/2)
	ci_upper <- quantile(boot_auprcs, 1 - alpha/2)

	# Calculate standard error
	se <- sd(boot_auprcs)

	auprc_print <- paste0('AUPRC: ', original_auprc %>% signif(digits = 3), '\ (', ci_lower %>% signif(digits = 3), ' – ', ci_upper %>% signif(digits = 3), ')')

	data %>%
		ci.coords(x = seq(0, 1, l = cut_by), ret = c('threshold', 'precision', 'recall'), conf.level = ci_level, boot.n = replicates) %>%
		as.data.frame() %>%
		as_tibble() %>%
		rename(
			precision_min = precision.2.5.,
			precision = precision.50.,
			precision_max = precision.97.5.,
			recall_min = recall.2.5.,
			recall = recall.50.,
			recall_max = recall.97.5.
		) %>%
		ggplot(
			aes(
				x = recall,
				y = precision,
				ymin = precision_min,
				ymax = precision_max
			)
		) +
		geom_ribbon(
			fill = pal_nejm()(2)[2],
			color = 'gray',
			alpha = 0.2
		) +
		geom_line(color = 'black', alpha = 0.9) +
		geom_hline(
			yintercept = data$response %>% as.numeric() %>% -1 %>% tabyl() %>% as_tibble() %>% filter(. == 1) %>% pull(percent),
			color = pal_nejm()(2)[1],
			linetype = 'longdash'
		) +
		theme_jgn() +
		labs(
			x = 'Recall',
			y = 'Precision'
		) +
		coord_equal(
			ylim = c(0, 1),
			xlim = c(0, 1)
		) +
		annotate(
			geom = 'text',
			x = 1,
			y = 0.96,
			label = auprc_print,
			family = font,
			size = 5,
			hjust = 1.05
		)
}

jgn_logit_linearity_plot <- function(model, axis_wrap_width = 40, facet_label_wrap_width = 40){
	data <- model %>%
		insight::get_predictors() %>%
		select_if(is.numeric)

	predictors <- data %>% names()
	predictor_labels <- map_chr(
		predictors,
		~(data %>% pull(.x) %>% var_label())
	)
	predictor_labeller <- predictor_labels %>%
		set_names(predictors)

	logit_data <- data %>%
		bind_cols(
			predicted_prob = predict(model, type = 'response'),
			outcome = model %>% insight::get_response()
		) %>%
		mutate(logit = log(predicted_prob/(1-predicted_prob))) %>%
		gather(key = 'predictors', value = 'predictor_value', -c(logit, predicted_prob, outcome))

	ggplot(
		data = logit_data,
		aes(
			x = predictor_value,
			y = logit,
			color = predictors %>% factor()
		)
	) +
		geom_point(size = 0.75, alpha = 0.5) +
		geom_smooth(method = 'loess', se = FALSE) +
		theme_jgn() +
		theme(legend.position = 'none') +
		labs(
			x = 'Predictor Value',
			y = paste0('Log-Odds of ', logit_data %>% pull(outcome) %>% var_label()) %>% str_wrap(width = axis_wrap_width)
		) +
		scale_color_nejm() +
		lemon::facet_rep_wrap(
			~predictors,
			scales = 'free',
			repeat.tick.labels = TRUE,
			labeller = labeller(
				predictors = predictor_labeller
			)
		)
}

jgn_calibration_plot <- function(model, n.boot = 1000, u_value = NULL, combined = TRUE, m_value = 5){
	if(!c('rms') %in% (model %>% attributes)$class){
		if('glm' %in% (model %>% attributes)$class){
			if(model$family$family == 'binomial'){
				model <- rms::lrm(
					formula = model$call$formula %>% as.formula(),
					data = model %>% get_data(),
					x = TRUE,
					y = TRUE
				)
			}
		}
		if('coxph' %in% (model %>% attributes)$class){
			model <- rms::cph(
				formula = model$call$formula %>% as.formula(),
				data = model %>% get_data(),
				x = TRUE,
				y = TRUE,
				surv = TRUE
			)
		}
	}

	if('lrm' %in% (model %>% attributes)$class){
		calibration_data <- rms::calibrate(
			model,
			method = 'boot',
			B = n.boot,
			conf.int = TRUE
		)

		calibration_df <- tibble(
			predicted_y = calibration_data[,'predy'],
			calibrated = calibration_data[,'calibrated.orig'],
			calibrated_corrected = calibration_data[,'calibrated.corrected']
		) %>%
			mutate(bin = ntile(predicted_y, 10)) %>%
			group_by(bin) %>%
			mutate(
				bin_mean = mean(predicted_y),
				bin_median = median(predicted_y)
			) %>%
			ungroup()

		empiric <- model$y
	}

	if('cph' %in% (model %>% attributes)$class){
		calibration_data <<- rms::calibrate(
			model,
			method = 'boot',
			B = n.boot,
			conf.int = TRUE,
			u = u_value,
			cmethod = 'KM',
			m = nrow(model$y)/m_value,
		)

		calibration_df <- tibble(
			predicted_y = calibration_data[,'KM'],
			calibrated = calibration_data[,'mean.predicted'],
			calibrated_corrected = calibration_data[,'mean.corrected'],
			se = calibration_data[,'std.err']
		) %>%
			mutate(bin = ntile(predicted_y, 10)) %>%
			group_by(bin) %>%
			mutate(
				bin_mean = mean(predicted_y),
				bin_median = median(predicted_y)
			) %>%
			ungroup()

		empiric <- model$y[,2]
	}

	empiric_factor <- empiric %>% factor()

	calibration_df <- calibration_df %>% left_join(
		.,
		calibration_df %>%
			group_by(bin) %>%
			do(
				Hmisc::smean.cl.boot(.$calibrated, B = n.boot) %>%
					rbind() %>%
					as_tibble() %>%
					setNames(c('boot_mean', 'ci_lb', 'ci_ub'))
			),
		by = c('bin' = 'bin')
	)

	calibration_rug <- tibble(
		predicted = (calibration_data %>% attributes())$predicted %>% as.numeric(),
		empiric = empiric,
		empiric_numeric = empiric
	)

	if('lrm' %in% (model %>% attributes)$class){
		calibration_rug <- calibration_rug %>%
			mutate(
				empiric_numeric = empiric_numeric %>% as.numeric() %>% -1
			)
	}

	ci_df <- calibration_df %>%
		group_by(bin) %>%
		do(
			Hmisc::smean.cl.boot(.$calibrated, B = n.boot) %>%
				rbind() %>%
				as_tibble() %>%
				setNames(c('boot_mean', 'ci_lb', 'ci_ub'))
		) %>%
		mutate(
			se = (ci_ub-ci_lb)/2
		) %>%
		left_join(
			.,
			calibration_df %>% select(bin, bin_mean) %>% distinct(),
			by = c('bin' = 'bin')
		)

	ci_df <- ci_df %>%
		bind_rows(
			c(
				'bin' = 0,
				bin_mean = calibration_df$predicted_y %>% min(),
				ci_lb = calibration_df$calibrated %>% min() - ci_df %>% filter(bin == 1) %>% pull(se),
				ci_ub = calibration_df$calibrated %>% min() + ci_df %>% filter(bin == 1) %>% pull(se),
				se = ci_df %>% filter(bin == 1) %>% pull(se)
			),
			c(
				'bin' = 11,
				bin_mean = calibration_df$predicted_y %>% max(),
				ci_ub = calibration_df$calibrated %>% max() + ci_df %>% filter(bin == 10) %>% pull(se),
				ci_lb = calibration_df$calibrated %>% max() - ci_df %>% filter(bin == 10) %>% pull(se),
				se = ci_df %>% filter(bin == 10) %>% pull(se)
			)
		) %>%
		arrange(bin)

	calplot <- ggplot(
		data = calibration_df,
		aes(
			x = calibrated,
			y = predicted_y
		)
	) +
		geom_abline(aes(intercept = 0, slope = 1, color = 'Ideal', linetype = 'Ideal'), show.legend = FALSE)

	if('lrm' %in% (model %>% attributes)$class){
		calplot <- calplot +
			geom_smooth(data = calibration_rug, aes(x = predicted, y = empiric_numeric), se = FALSE, linewidth = 0.5, color = 'black') +
			stat_smooth(data = calibration_rug, inherit.aes = FALSE, aes(x = predicted, y = empiric_numeric, fill = 'Apparent'), color = 'gray', method = 'loess', geom = 'ribbon', show.legend = FALSE, alpha = 0.15)
	}

	if('cph' %in% (model %>% attributes)$class){
		calplot <- calplot +
			geom_ribbon(
				data = calibration_df,
				inherit.aes = FALSE,
				aes(
					x = calibrated,
					y = predicted_y,
					ymin = predicted_y-se,
					ymax = predicted_y+se
				),
				fill = pal_nejm()(2)[2],
				color = 'gray',
				# show_legend = FALSE,
				# width = 0.01
				alpha = 0.15,
			) +
			geom_line(aes(color = 'Apparent', linetype = 'Apparent'))
		# geom_line(aes(y = calibrated_corrected, color = 'Bias-Corrected', linetype = 'Bias-Corrected'))
	}

	calplot <- calplot +
		geom_rug(data = calibration_rug, inherit.aes = FALSE, aes(x = predicted), sides = 't', length = unit(0.02, 'npc'), alpha = 0.5) +
		theme_jgn() +
		theme(
			legend.position = 'top',
			legend.margin = margin(0, unit = 'cm'),
			legend.box.spacing = unit(0.25, 'cm'),
			axis.title.y = element_text(margin = margin(r = 10))
		) +
		labs(
			# x = 'Predicted Probability',
			x = element_blank(),
			y = 'Empirical Probability'
		) +
		#coord_equal() +
		coord_cartesian(xlim = c(0,1), ylim = c(0,1)) +
		scale_x_continuous(breaks = seq(0, 1, 0.1)) +
		scale_y_continuous(breaks = seq(0, 1, 0.1)) +
		scale_linetype_manual(
			name = 'Prediction',
			breaks = c('Apparent', 'Bias-Corrected', 'Ideal'),
			values = c(
				'Ideal' = 'longdash',
				'Apparent' = 'solid',
				'Bias-Corrected' = 'dotted'
			)
		) +
		scale_color_manual(
			name = 'Prediction',
			breaks = c('Apparent', 'Bias-Corrected', 'Ideal'),
			values = c(
				'Ideal' = pal_nejm()(2)[1],
				'Apparent' = pal_nejm()(3)[2],
				'Bias-Corrected' = pal_nejm()(3)[3]
			)
		) +
		scale_fill_manual(
			name = 'Prediction',
			breaks = c('Apparent', 'Bias-Corrected', 'Ideal'),
			values = c(
				'Ideal' = pal_nejm()(2)[1],
				'Apparent' = pal_nejm()(3)[2],
				'Bias-Corrected' = pal_nejm()(3)[3]
			)
		)

	# Rug
	rugplot <- ggplot(
		calibration_rug %>%
			filter(empiric == levels(empiric_factor)[1]),
		aes(x = predicted)
	) +
		geom_histogram(
			aes(
				y = ..density..
			),
			fill = 'white',
			color = 'black',
			alpha = 0.75,
			bins = 100
		) +
		geom_histogram(
			data = calibration_rug %>%
				filter(empiric == levels(empiric_factor)[2]),
			aes(
				y = -..density..
			),
			fill = 'black',
			color = 'black',
			alpha = 0.75,
			bins = 100
		) +
		scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.1)) +
		scale_y_continuous(labels = function(x) abs(x)) +
		labs(
			x = 'Predicted Probability',
			y = ''
			#y = 'Density'
		) +
		theme_jgn() +
		theme(
			legend.position = 'top',
			panel.grid.minor = element_blank(),
			axis.title.y = element_blank(),
			axis.text.y = element_blank(),
			axis.ticks.y = element_blank(),
			axis.title.x = element_text(margin = margin(t = 5))
		)

	calplot_combined <-
		cowplot::plot_grid(
			calplot,
			rugplot,
			align = 'v',
			ncol = 1,
			rel_heights = c(0.75, 0.25)
		)

	if(combined){
		calplot_combined %>% print()
	} else {
		(calplot + labs(x = 'Predicted Probability') + theme(axis.title.x = element_text(margin = margin(t = 5)))) %>% print()
	}

}

theme_jgn <- function (base_size = 14, base_family = 'EB Garamond', base_line_size = base_size / 22, base_rect_size = base_size / 22, caption_text_size = 12, caption_text_margin = 5, subtitle_size = 16, subtitle_margin = 10, plot_title_size = 16, plot_title_margin = 10, ...){
	# From: https://github.com/juliasilge/silgelib/blob/main/R/graphing.R
	# And: https://emanuelaf.github.io/own-ggplot-theme.html
	ggplot2::theme_grey(
		base_size = base_size,
		base_family = base_family,
		base_line_size = base_line_size,
		base_rect_size = base_rect_size,
		...
	) %+replace%
		ggplot2::theme(
			plot.title = ggplot2::element_text(
				hjust = 0,
				size = plot_title_size,
				margin = ggplot2::margin(b = plot_title_margin),
				family = base_family,
				face = 'bold'
			),
			plot.subtitle = ggplot2::element_text(
				hjust = 0,
				size = subtitle_size,
				margin = ggplot2::margin(b = subtitle_margin),
				family = base_family
			),
			plot.caption = ggplot2::element_text(
				hjust = 1,
				size = caption_text_size,
				margin = ggplot2::margin(b = caption_text_margin),
				family = base_family,
				face = 'italic'
			),
			# strip.text = ggplot2::element_text(
			# 	hjust = 0,
			# 	size = strip_text_size,
			# 	margin = ggplot2::margin(b = strip_text_margin),
			# 	family = bold_family
			# ),
			panel.background = ggplot2::element_rect(fill = 'white', colour = NA),
			panel.border = ggplot2::element_rect(fill = NA, colour = 'grey20'),
			panel.grid = ggplot2::element_line(colour = 'grey92'),
			panel.grid.minor = ggplot2::element_line(linewidth = rel(0.5)),
			strip.background = ggplot2::element_rect(fill = 'grey85', colour = 'grey20'),
			legend.position = 'top',
			legend.key = ggplot2::element_rect(fill = 'white', colour = NA),
			complete = TRUE
		)
}
