jgn_glmnet_lasso <- function(predictors, response, n_cv_folds = 10, ...){
	require(glmnet, warn.conflicts = FALSE, quietly = TRUE)

	if(!is.matrix(predictors)){
		predictors <- model.matrix(~ ., data = predictors)
	}

	if(!inherits(response, 'Surv')){
		return('Response must be a Surv object')
	}

	if(predictors %>% nrow() != response %>% length()){
		return('Length of predictors and response unequal.')
	}

	set.seed(42)
	doParallel::registerDoParallel()

	lasso_fit <- cv.glmnet(
		x = predictors,
		y = response,
		family = 'cox',
		type.measure = 'C',
		alpha = 1,
		nfolds = n_cv_folds,
		parallel = TRUE,
		...
	)

	lasso_fit_deviance <- cv.glmnet(
		x = predictors,
		y = response,
		family = 'cox',
		type.measure = 'deviance',
		alpha = 1,
		nfolds = n_cv_folds,
		parallel = TRUE,
		...
	)

	lasso_fit_list <<- list(
		c_index = lasso_fit,
		deviance = lasso_fit_deviance
	)

	lasso_fit_table <- tibble()

	walk(
		lasso_fit_list,
		function(.x){
			best_fit <- .x %>%
				glance()

			lasso_fit_table <<- lasso_fit_table %>%
				bind_rows(
					.x %>%
						tidy() %>%
						filter(lambda == best_fit$lambda.min) %>%
						mutate(
							metric = .x$name %>% unname(),
							fit_type = 'min',
							vi = .x %>%
								vi(lambda = best_fit$lambda.min) %>%
								nest()
						),
					.x %>%
						tidy() %>%
						filter(lambda == best_fit$lambda.1se) %>%
						mutate(
							metric = .x$name %>% unname(),
							fit_type = '1se',
							vi = .x %>%
								vi(lambda = best_fit$lambda.1se) %>%
								nest()
						)
				)
		}
	)

	lasso_fit_table <<- lasso_fit_table %>%
		mutate(
			alpha = 1,
			cv_folds = n_cv_folds
		) %>%
		relocate(c(alpha, cv_folds, metric, fit_type)) %>%
		unnest(cols = c(vi)) %>%
		rename(vi = data) %>%
		relocate(vi, .after = last_col())
}

jgn_glmnet_parameter_plot <- function(object, sign.lambda = 1, label.n = 12, xlab = NULL, ylab = NULL, n_breaks_x = NULL, n_breaks_y = NULL, plotly_enable = FALSE, ...){
	require(ggfortify, warn.conflicts = FALSE, quietly = TRUE)

	if(is.null(xlab)){
		xlab <- latex2exp::TeX('log(\\lambda)')
		if(sign.lambda < 0){
			xlab <- paste('-', xlab, sep = '')
		}
	}
	if(is.null(ylab)){
		type_measure <- object$name
		ylab <- type_measure[[names(type_measure)[[1]]]] %>% str_to_title()
	}
	plot.data <- fortify(object)
	plot.data$lambda <- sign.lambda * plot.data$lambda
	plot.data$label <- rep(max(object$cvup), nrow(plot.data))
	indexer <- seq(1, nrow(plot.data), length = label.n)

	p <- ggplot2::ggplot(
		data = plot.data
	) +
		geom_vline(
			xintercept = sign.lambda * log(object$lambda.min),
			linetype = 'dashed'
			# color = pal_nejm()(8)[4]
		) +
		geom_vline(
			xintercept = sign.lambda * log(object$lambda.1se),
			linetype = 'dashed',
			color = '#666666'
			# color = pal_nejm()(8)[2]
		) +
		geom_point(
			aes(
				x = lambda,
				y = cvm,
				color = names(object$name)
			),
			...
		) +
		geom_errorbar(
			aes(
				x = lambda,
				ymin = cvlo,
				ymax = cvup,
				color = names(object$name)
			),
			alpha = 0.5,
			width = 0.10,
			...
		) +
		geom_label(
			inherit.aes = FALSE,
			data = plot.data[indexer, ],
			aes(
				x = lambda,
				y = label,
				label = nz
			),
			family = 'EB Garamond',
			fontface = 'bold',
			...
		) +
		theme_jgn() +
		theme(
			legend.position = 'none',
			...
		) +
		scale_color_manual(
			values = c(
				'C' = pal_nejm()(8)[1],
				'deviance' = pal_nejm()(8)[3]
			)
		) +
		labs(
			x = xlab,
			y = ylab
		)

	if(is_empty(n_breaks_x)){
		p <- p +
			scale_x_continuous(n.breaks = n_breaks_x)
	} else {
		p <- p +
			scale_x_continuous(n.breaks = 6)
	}

	if(!is_empty(n_breaks_y)){
		p <- p +
			scale_y_continuous(n.breaks = n_breaks_y)
	} else {
		if(!str_detect(object$name %>% str_to_lower, 'deviance')){
			p <- p +
				scale_y_continuous(n.breaks = 6)
		} else {
			p <- p +
				scale_y_continuous(n.breaks = 8)
		}
	}

	if(plotly_enable){
		p %>% plotly::ggplotly()
	} else {
		p
	}

}

jgn_glmnet_importance_table <- function(vi_data){
	vi_data %>%
		pull(vi) %>%
		pluck(1) %>%
		mutate(
			Variable = Variable %>% fct_reorder(Importance),
			Sign = Sign %>% fct_recode(
				'Positive' = 'POS', 'Negative' = 'NEG'
			)
		) %>%
		filter(Importance != 0)
}

jgn_glmnet_importance_plot <- function(fit_data){
	ggplot(
		data = fit_data %>%
			jgn_glmnet_importance_table(),
		aes(
			x = Importance,
			y = Variable,
			fill = Sign
		)
	) +
		geom_col() +
		theme_jgn() +
		scale_fill_nejm() +
		labs(y = NULL)
}

jgn_glmnet_elastic_net <- function(predictors, response, n_cv_folds = 10, ...){
	require(glmnet, warn.conflicts = FALSE, quietly = TRUE)

	if(!is.matrix(predictors)){
		predictors <- model.matrix(~ ., data = predictors)
	}

	if(!inherits(response, 'Surv')){
		return('Response must be a Surv object')
	}

	if(predictors %>% nrow() != response %>% length()){
		return('Length of predictors and response unequal.')
	}

	alpha_key <- grid_regular(
		mixture(),
		levels = c(mixture = 10)
	) %>%
		filter(mixture != 1) %>%
		mutate(
			print_name = paste0('alpha_', mixture %>% round(digits = 2))
		)

	metric_key <- tribble(
		~metric, ~print_name,
		'c_index', 'C-index',
		'deviance', 'Partial Likelihood Deviance'
	)

	set.seed(42)
	doParallel::registerDoParallel()

	elastic_net_fit_list <<- list()

	walk(
		alpha_key %>%
			pull(mixture),
		function(.x){
			fit_name <- paste0('alpha_', .x %>% round(digits = 2))

			elastic_net_fit_list[['c_index']][[fit_name]] <<- cv.glmnet(
				x = predictors,
				y = response,
				family = 'cox',
				type.measure = 'C',
				alpha = .x,
				nfolds = n_cv_folds,
				parallel = TRUE,
				...
			)

			elastic_net_fit_list[['deviance']][[fit_name]] <<- cv.glmnet(
				x = predictors,
				y = response,
				family = 'cox',
				type.measure = 'deviance',
				alpha = .x,
				nfolds = n_cv_folds,
				parallel = TRUE,
				...
			)
		},
		.progress = TRUE
	)

	elastic_net_fit_table <- tibble()

	iwalk(
		c(
			elastic_net_fit_list$c_index,
			elastic_net_fit_list$deviance
		),
		function(.x, .y){
			best_fit <- .x %>%
				glance()

			elastic_net_fit_table <<- elastic_net_fit_table %>%
				bind_rows(
					.x %>%
						tidy() %>%
						filter(lambda == best_fit$lambda.min) %>%
						mutate(
							alpha = alpha_key %>% filter(print_name == .y) %>% pull(mixture),
							metric = .x$name %>% unname(),
							fit_type = 'min',
							vi = .x %>%
								vi(lambda = best_fit$lambda.min) %>%
								nest()
						),
					.x %>%
						tidy() %>%
						filter(lambda == best_fit$lambda.1se) %>%
						mutate(
							alpha = alpha_key %>% filter(print_name == .y) %>% pull(mixture),
							metric = .x$name %>% unname(),
							fit_type = '1se',
							vi = .x %>%
								vi(lambda = best_fit$lambda.1se) %>%
								nest()
						)
				)
		}
	)

	elastic_net_fit_table <<- elastic_net_fit_table %>%
		mutate(cv_folds = n_cv_folds) %>%
		relocate(c(alpha, cv_folds, metric, fit_type)) %>%
		unnest(cols = c(vi)) %>%
		rename(vi = data) %>%
		relocate(vi, .after = last_col())

	elastic_net_best_fit_table <<- bind_rows(
		elastic_net_fit_table %>%
			group_by(fit_type) %>%
			filter(metric == 'C-index') %>%
			filter(estimate == max(estimate)) %>%
			ungroup(),
		elastic_net_fit_table %>%
			group_by(fit_type) %>%
			filter(metric == 'Partial Likelihood Deviance') %>%
			filter(estimate == min(estimate)) %>%
			ungroup()
	) %>%
		mutate(cv_folds = n_cv_folds) %>%
		relocate(c(alpha, cv_folds, metric, fit_type)) %>%
		unnest(cols = c(vi)) %>%
		rename(vi = data) %>%
		relocate(vi, .after = last_col())

	elastic_net_best_fits <- elastic_net_best_fit_table %>%
		left_join(
			.,
			alpha_key %>%
				rename(alpha_print = print_name),
			by = c('alpha' = 'mixture')
		) %>%
		left_join(
			.,
			metric_key %>%
				rename(
					metric_print = metric
				),
			by = c('metric' = 'print_name')
		) %>%
		mutate(
			object_name = paste0(metric_print, '_', fit_type)
		) %>%
		select(metric_print, fit_type, object_name, alpha_print) %>%
		distinct()

	metric_names <- elastic_net_best_fits %>%
		pull(metric_print) %>%
		unique()

	fit_types <- elastic_net_best_fits %>%
		pull(fit_type) %>%
		unique()

	object_names <- elastic_net_best_fits %>%
		pull(object_name)

	alpha_names <- elastic_net_best_fits %>%
		pull(alpha_print)

	elastic_net_best_fit_list <<- rlang::rep_named(
		metric_names,
		list(
			rlang::rep_named(fit_types, list())
		)
	)

	walk2(
		.x = object_names,
		.y = alpha_names,
		function(.x, .y){
			parent <- elastic_net_best_fits %>%
				filter(object_name == .x) %>%
				pull(metric_print)

			fit_type <- elastic_net_best_fits %>%
				filter(object_name == .x) %>%
				pull(fit_type)

			fit_object <- elastic_net_fit_list %>%
				pluck(parent) %>%
				pluck(.y)

			elastic_net_best_fit_list[[parent]][[fit_type]] <<- fit_object

		}
	)
}

jgn_glmnet_table_print <- function(data, alpha_round_digits = 2, single_metric = FALSE, single_lambda = FALSE, ...){
	output <- data %>%
		select(-one_of('std.error', 'conf.low', 'conf.high', 'vi')) %>%
		mutate(
			alpha = sprintf(paste0('%0.', alpha_round_digits, 'f'), alpha),
			cv_folds = paste0('$n = ', cv_folds, '$'),
			fit_type = paste0('$\\lambda_{', fit_type, '}$'),
			candidates = predictors %>% ncol()-1
		) %>%
		set_variable_labels(
			alpha = '$\\alpha$',
			cv_folds = 'Cross-Validation Folds',
			metric = 'Metric',
			fit_type = 'Fit Type',
			lambda = '$\\lambda$',
			estimate = 'Estimate',
			# std.error = '',
			# conf.low = '',
			# conf.high = '',
			nzero = 'Non-Zero Coefficients',
			candidates = 'Candidate Coefficients'
		)

	if(single_metric){
		output <- output %>%
			set_variable_labels(
				estimate = (output %>% pull(metric) %>% unique())
			) %>%
			select(-metric)
	}

	if(single_lambda){
		output <- output %>%
			set_variable_labels(
				lambda = (output %>% pull(fit_type) %>% unique())
			) %>%
			select(-fit_type)
	}

	output %>%
		finalfit::labels_to_column() %>%
		printKable(format = 'markdown', ...)
}

jgn_glmnet_lasso_output_results <- function(fit_list, base_heading = '#'){
	fit_list %>%
		iwalk(
			function(.fit_object, .fit_name){
				fit_metric <- .fit_object$name %>% unname()

				cat(base_heading, '# ', fit_metric, '\n\n', sep = '')
				cat('<div class="panel-tabset">\n\n')

				fit_table <- lasso_fit_table %>%
					filter(metric == fit_metric)

				fit_types <- fit_table %>%
					pull(fit_type) %>%
					unique()

				parameter_plot <- .fit_object %>%
					jgn_glmnet_parameter_plot()

				iwalk(
					fit_types,
					function(.fit_type, .fit_type_name){
						fit_type_table <- fit_table %>%
							filter(fit_type == .fit_type)

						summary_table <- fit_type_table %>%
							jgn_glmnet_table_print(single_metric = TRUE, single_lambda = TRUE)

						vi_table <- fit_type_table %>%
							jgn_glmnet_importance_table()

						vi_plot <- fit_type_table %>%
							jgn_glmnet_importance_plot()

						cat(base_heading, '## $\\lambda_{', .fit_type, '}$\n\n', sep = '')
						cat('<div class="panel-tabset">\n\n')

						cat(base_heading, '### Summary Table\n\n', sep = '')
						summary_table %>% print()

						cat(base_heading, '### Regularization Parameter Plot\n\n', sep = '')
						parameter_plot %>% print()

						cat('\n\n', base_heading, '### Variable Importance\n\n', sep = '')
						cat('<div class="panel-tabset">\n\n')

						cat(base_heading, '#### Table\n\n', sep = '')
						vi_table %>%
							print_kable() %>%
							fmt_number(
								columns = one_of('Importance'),
								decimals = 8
							) %>%
							print()

						cat(base_heading, '#### Plot\n\n', sep = '')
						vi_plot %>%
							print()

						cat('</div>\n\n')

						cat('</div>\n\n')
					}
				)

				cat('</div>\n\n')
			}
		)
}

jgn_glmnet_elastic_net_output_results <- function(fit_list, base_heading = '#'){
	metric_key <- tribble(
		~metric, ~print_name,
		'c_index', 'C-index',
		'deviance', 'Partial Likelihood Deviance'
	)

	fit_list %>%
		iwalk(
			function(.list_object, .metric_name){
				fit_metric <- metric_key %>%
					filter(metric == .metric_name) %>%
					pull(print_name)

				cat(base_heading, '# ', fit_metric, '\n\n', sep = '')
				cat('<div class="panel-tabset">\n\n')

				fit_table <- elastic_net_best_fit_table %>%
					filter(metric == fit_metric)

				fit_types <- fit_table %>%
					pull(fit_type) %>%
					unique()

				walk(
					fit_types,
					function(.fit_type){
						parent_object <- .list_object %>%
							pluck(.fit_type)

						fit_type_table <- fit_table %>%
							filter(fit_type == .fit_type)

						summary_table <- fit_type_table %>%
							jgn_glmnet_table_print(single_metric = TRUE, single_lambda = TRUE)

						parameter_plot <- parent_object %>%
							jgn_glmnet_parameter_plot()

						vi_table <- fit_type_table %>%
							jgn_glmnet_importance_table()

						vi_plot <- fit_type_table %>%
							jgn_glmnet_importance_plot()

						cat(base_heading, '## $\\lambda_{', .fit_type, '}$\n\n', sep = '')
						cat('<div class="panel-tabset">\n\n')

						cat(base_heading, '### Summary Table\n\n', sep = '')
						summary_table %>% print()

						cat(base_heading, '### Regularization Parameter Plot\n\n', sep = '')
						parameter_plot %>% print()

						cat('\n\n', base_heading, '### Variable Importance\n\n', sep = '')
						cat('<div class="panel-tabset">\n\n')

						cat(base_heading, '#### Table\n\n', sep = '')
						vi_table %>%
							print_kable() %>%
							fmt_number(
								columns = one_of('Importance'),
								decimals = 8
							) %>%
							print()

						cat(base_heading, '#### Plot\n\n', sep = '')
						vi_plot %>%
							print()

						cat('</div>\n\n')

						cat('</div>\n\n')
					}
				)

				cat('</div>\n\n')
			}
		)
}
