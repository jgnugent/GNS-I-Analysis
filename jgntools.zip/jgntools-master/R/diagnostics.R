printVIF <- function(model, rms = FALSE, round_digits = 3, bold_threshold = 5, underline_threshold = 10, print_label = TRUE){
	if(rms){
		output <- model %>%
			rms::vif()
	} else {
		output <- model %>%
			car::vif()
	}

	output <- output %>%
		as_tibble(rownames = 'Term') %>%
		rename(
			any_of(
				c(
					VIF = 'GVIF',
					VIF = 'value'
				)
			)
		) %>%
		mutate(
			`Tolerance` = 1/VIF,
			across(
				one_of('VIF', 'GVIF^(1/(2*Df))', 'Tolerance'),
				~sprintf(paste0('%0.', round_digits, 'f'), .x))
		) %>%
		relocate(`Tolerance`, .after = VIF)

	if(!rms & print_label){
		output <- output %>%
			rowwise() %>%
			mutate(
				Term = model %>% get_data() %>% pull(Term) %>% var_label()
			)
	}

	output %>%
		print_kable() %>%
		tab_style(
			style = cell_text(weight = 'bold'),
			locations = cells_body(
				columns = everything(),
				rows = VIF > bold_threshold
			)
		) %>%
		tab_style(
			style = cell_text(decorate = 'underline'),
			locations = cells_body(
				columns = everything(),
				rows = VIF > underline_threshold
			)
		) %>%
		tab_caption(caption = 'The variance inflation factor (VIF) is a measure to analyze the magnitude of multicollinearity of model terms. A VIF of less than 5 indicates a low correlation of that predictor with other predictors. A value between 5 and 10 indicates a moderate correlation, while VIF values larger than 10 are a sign of a high, non-tolerable correlation of model predictors.') %>%
		opt_footnote_marks(marks = 'extended') %>%
		tab_footnote(
			footnote = html('<b>Tolerance</b> = 1/VIF.'),
			locations = cells_column_labels(columns = `Tolerance`)
		)
}

printVIF_easystats <- function(model, round_digits = 3, bold_threshold = 5, underline_threshold = 10, print_label = TRUE){
	output <- model %>%
		check_collinearity() %>%
		as_tibble() %>%
		mutate_if(is.numeric, ~sprintf(paste0('%0.', round_digits, 'f'), .x)) %>%
		mutate(
			`VIF 95% CI` = paste0('(', VIF_CI_low, ' – ', VIF_CI_high, ')'),
			`Tolerance 95% CI` = paste0('(', Tolerance_CI_low, ' – ', Tolerance_CI_high, ')'),
		) %>%
		relocate(`VIF 95% CI`, .after = VIF) %>%
		relocate(`Tolerance 95% CI`, .after = Tolerance) %>%
		select(-one_of('VIF_CI_low', 'VIF_CI_high', 'Tolerance_CI_low', 'Tolerance_CI_high')) %>%
		rename(
			`SE Factor` = SE_factor,
			`Tolerance` = Tolerance
		)

	if(print_label){
		output <- output %>%
			rowwise() %>%
			mutate(
				Term = model %>% get_data() %>% pull(Term) %>% var_label()
			)
	}

	output %>%
		print_kable() %>%
		tab_style(
			style = cell_text(weight = 'bold'),
			locations = cells_body(
				columns = everything(),
				rows = VIF > bold_threshold
			)
		) %>%
		tab_style(
			style = cell_text(decorate = 'underline'),
			locations = cells_body(
				columns = everything(),
				rows = VIF > underline_threshold
			)
		) %>%
		opt_footnote_marks(marks = 'extended') %>%
		tab_footnote(
			footnote = 'The factor by which the standard error is increased due to possible correlation with other terms.',
			location = cells_column_labels(columns = `SE Factor`)
		) %>%
		tab_footnote(
			footnote = html('<b>Tolerance</b> = 1/VIF.'),
			location = cells_column_labels(columns = `Tolerance`)
		)
}

print_convergence_check <- function(model, gradient_digits = 10){
	object <- model %>%
		check_convergence()

	gradient <- object %>%
		attr('gradient') %>%
		round(digits = gradient_digits)

	if(object %>% remove_attributes('gradient')){
		insight::print_color(paste0('OK: Convergence within acceptable limits (gradient = ', gradient, ').'), 'green')
	} else {
		insight::print_color('Warning: Convergence is suspicious.', 'red')
	}
}

print_singularity_check <- function(model){
	if(model %>% check_singularity() %>% `!`){
		insight::print_color('OK: Singular model fit not detected.', 'green')
	} else {
		insight::print_color('Warning: Singular model fit detected.', 'red')
	}
}
