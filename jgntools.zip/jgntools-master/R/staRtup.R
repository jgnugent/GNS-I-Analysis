librarian::shelf(
  broom.mixed, easystats, embed, extrafont, finetune, forestmodel, ggalluvial, ggsci, gt, gtsummary, haven, janitor, kableExtra, labelled, laviz, ldatools, leaflet, lemon, lme4, Microsoft365R, naniar, partDSA, pins, plotly, probably, pROC, readxl, rms, rstatix, scales, sf, shapviz, skimr, survival, survminer, sysfonts, tableone, tidymodels, tidyverse, vip,
  quiet = TRUE
)

resolve_conflicts <- function(){
	tidymodels::tidymodels_prefer()
	conflicted::conflict_prefer_all('dplyr', quiet = TRUE)
	conflicted::conflict_prefer_all('ggsci', quiet = TRUE)
	conflicted::conflict_prefer_all('rstatix', quiet = TRUE)
	conflicted::conflict_prefer('+.gg', 'ggplot2', quiet = TRUE)
	conflicted::conflicts_prefer(pROC::auc)
	conflicted::conflict_prefer('chisq.test', 'stats', quiet = TRUE)
	conflicted::conflict_prefer('clean_names', 'janitor', quiet = TRUE)
	conflicted::conflict_prefer('cohens_d', 'effectsize', quiet = TRUE)
	conflicted::conflict_prefer('col_factor', 'readr', quiet = TRUE)
	conflicted::conflict_prefer('cor_test', 'correlation', quiet = TRUE)
	conflicted::conflict_prefer('discard', 'purrr', quiet = TRUE)
	conflicted::conflict_prefer('eta_squared', 'effectsize', quiet = TRUE)
	conflicted::conflict_prefer('expand', 'tidyr', quiet = TRUE)
	conflicted::conflict_prefer('fisher.test', 'stats', quiet = TRUE)
	conflicted::conflict_prefer('fixed', 'recipes', quiet = TRUE)
	conflicted::conflict_prefer('get_emmeans', 'modelbased', quiet = TRUE)
	conflicted::conflict_prefer('html', 'gt', quiet = TRUE)
	conflicted::conflict_prefer('lag', 'dplyr', quiet = TRUE)
	conflicted::conflict_prefer('layout', 'plotly', quiet = TRUE)
	conflicted::conflict_prefer('make_clean_names', 'janitor', quiet = TRUE)
	conflicted::conflict_prefer('mean_sd', 'ggpubr', quiet = TRUE)
	conflicted::conflict_prefer('median_mad', 'ggpubr', quiet = TRUE)
	conflicted::conflict_prefer('p_value', 'parameters', quiet = TRUE)
	conflicted::conflict_prefer('pack', 'tidyr', quiet = TRUE)
	conflicted::conflict_prefer('parameters', 'dials', quiet = TRUE)
	conflicted::conflict_prefer('plot.transform ', 'scales', quiet = TRUE)
	conflicted::conflict_prefer('remove_empty_rows', 'janitor', quiet = TRUE)
	conflicted::conflict_prefer('remove_empty', 'janitor', quiet = TRUE)
	conflicted::conflict_prefer('remove_labels', 'labelled', quiet = TRUE)
	conflicted::conflict_prefer('rescale', 'scales', quiet = TRUE)
	conflicted::conflict_prefer('skewness', 'dlookr', quiet = TRUE)
	conflicted::conflict_prefer('smoothness', 'dials', quiet = TRUE)
	conflicted::conflict_prefer('subplot', 'plotly', quiet = TRUE)
	conflicted::conflict_prefer('translate', 'parsnip', quiet = TRUE)
	conflicted::conflict_prefer('unpack', 'tidyr', quiet = TRUE)
	conflicted::conflict_prefer('update', 'recipes', quiet = TRUE)
	conflicted::conflict_prefer('vi', 'vip', quiet = TRUE)
}

register_startup_packages <- function(packages = c('dplyr')){
	librarian::lib_startup(packages)
}

# conflicted::conflict_scout()

# usethis::use_package('', type = 'depends')
# usethis::use_rmarkdown_template(template_name = 'JGN Rmd *** Template', template_dir = 'jgn-rmd-***')
