jgn_lasso <- function(recipe = lasso_recipe, n_cv_folds = 10, penalty_min = -6){
	# From: https://www.tidymodels.org/start/case-study/
	# From: https://juliasilge.com/blog/lasso-the-office/

	outcome_varname <<- recipe$var_info %>%
		filter(role == 'outcome') %>%
		pull(variable) %>%
		as.character()

	set.seed(234)
	lasso_cv_folds <<- vfold_cv(lasso_train, strata = outcome_varname, v = n_cv_folds)

	lasso_model <<- logistic_reg(penalty = tune(), mixture = 1) %>%
		set_engine('glmnet')
		# set_engine('glmnet', weights = .dat()$ipw)

	lasso_workflow <<- workflow() %>%
		add_recipe(
			recipe %>%
				step_zv(all_predictors()) %>%
				step_normalize(all_numeric_predictors())
		) %>%
		add_model(lasso_model)

	# Parallel Processing
	doParallel::registerDoParallel()

	penalty_min <<- penalty_min

	if(lasso_model$mode == 'regression'){
		lasso_metrics <<- metric_set(yardstick::rmse, rsq, rsq_trad, yardstick::mae, ccc)
	}

	if(lasso_model$mode == 'classification'){
		lasso_metrics <<- metric_set(roc_auc, pr_auc, accuracy, bal_accuracy, kap, mcc, mn_log_loss)
	}

	set.seed(456)
	lasso_grid <<- tune_grid(
		lasso_workflow,
		resamples = lasso_cv_folds,
		grid = grid_regular(
			penalty(range = c(penalty_min, 0)),
			levels = 50
		),
		control = control_grid(save_pred = TRUE),
		metrics = lasso_metrics
	)

	lasso_auc_max <<- lasso_grid %>%
		select_best(metric = 'roc_auc')
	final_lasso_auc_max <<- finalize_workflow(
		lasso_workflow,
		lasso_auc_max
	)

	lasso_auc_1se <<- lasso_grid %>%
		select_by_one_std_err(metric = 'roc_auc', desc(penalty))
	final_lasso_auc_1se <<- finalize_workflow(
		lasso_workflow,
		lasso_auc_1se
	)

	lasso_auc_pct <<- lasso_grid %>%
		select_by_pct_loss(metric = 'roc_auc', desc(penalty))
	final_lasso_auc_pct <<- finalize_workflow(
		lasso_workflow,
		lasso_auc_pct
	)

	lasso_accuracy_max <<- lasso_grid %>%
		select_best(metric = 'accuracy')
	final_lasso_accuracy_max <<- finalize_workflow(
		lasso_workflow,
		lasso_accuracy_max
	)

	lasso_accuracy_1se <<- lasso_grid %>%
		select_by_one_std_err(metric = 'accuracy', desc(penalty))
	final_lasso_accuracy_1se <<- finalize_workflow(
		lasso_workflow,
		lasso_accuracy_1se
	)

	lasso_accuracy_pct <<- lasso_grid %>%
		select_by_pct_loss(metric = 'accuracy', desc(penalty))
	final_lasso_accuracy_pct <<- finalize_workflow(
		lasso_workflow,
		lasso_accuracy_pct
	)

	lasso_log_loss_max <<- lasso_grid %>%
		select_best(metric = 'mn_log_loss')
	final_lasso_log_loss_max <<- finalize_workflow(
		lasso_workflow,
		lasso_log_loss_max
	)

	lasso_log_loss_1se <<- lasso_grid %>%
		select_by_one_std_err(metric = 'mn_log_loss', desc(penalty))
	final_lasso_log_loss_1se <<- finalize_workflow(
		lasso_workflow,
		lasso_log_loss_1se
	)

	lasso_log_loss_pct <<- lasso_grid %>%
		select_by_pct_loss(metric = 'mn_log_loss', desc(penalty))
	final_lasso_log_loss_pct <<- finalize_workflow(
		lasso_workflow,
		lasso_log_loss_pct
	)
}

jgn_elastic_net <- function(recipe = lasso_recipe){
	# From: https://www.jkangpathology.com/post/tidymodel-and-glmnet/
	# From: https://www.kaggle.com/issactoast/lasso-with-tidymodels
	# From: https://www.kaggle.com/issactoast/tuning-lasso-with-tidymodels#set-the-tuning-spec
	# From: https://www.kaggle.com/issactoast/elastic-net-tunning-with-tidymodels
	elastic_net_model <<- lasso_model %>% update(mixture = tune())

	elastic_net_workflow <<- workflow() %>%
		add_recipe(
			recipe %>%
				step_zv(all_predictors()) %>%
				step_normalize(all_numeric_predictors())
		) %>%
		add_model(elastic_net_model)

	# Parallel Processing
	doParallel::registerDoParallel()

	set.seed(42)
	elastic_net_grid <<- tune_grid(
		elastic_net_workflow,
		resamples = lasso_cv_folds,
		grid = grid_regular(
			penalty(range = c(penalty_min, 0)),
			mixture(),
			levels = list(penalty = 100, mixture = 10)
		),
		control = control_grid(save_pred = TRUE),
		metrics = lasso_metrics
	)

	elastic_net_auc_max <<- elastic_net_grid %>%
		select_best(metric = 'roc_auc')
	final_elastic_net_auc_max <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_auc_max
	)

	elastic_net_auc_1se <<- elastic_net_grid %>%
		select_by_one_std_err(metric = 'roc_auc', desc(penalty))
	final_elastic_net_auc_1se <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_auc_1se
	)

	elastic_net_auc_pct <<- elastic_net_grid %>%
		select_by_pct_loss(metric = 'roc_auc', desc(penalty))
	final_elastic_net_auc_pct <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_auc_pct
	)

	elastic_net_accuracy_max <<- elastic_net_grid %>%
		select_best(metric = 'accuracy')
	final_elastic_net_accuracy_max <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_accuracy_max
	)

	elastic_net_accuracy_1se <<- elastic_net_grid %>%
		select_by_one_std_err(metric = 'accuracy', desc(penalty))
	final_elastic_net_accuracy_1se <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_accuracy_1se
	)

	elastic_net_accuracy_pct <<- elastic_net_grid %>%
		select_by_pct_loss(metric = 'accuracy', desc(penalty))
	final_elastic_net_accuracy_pct <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_accuracy_pct
	)

	elastic_net_log_loss_max <<- elastic_net_grid %>%
		select_best(metric = 'mn_log_loss')
	final_elastic_net_log_loss_max <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_log_loss_max
	)

	elastic_net_log_loss_1se <<- elastic_net_grid %>%
		select_by_one_std_err(metric = 'mn_log_loss', desc(penalty))
	final_elastic_net_log_loss_1se <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_log_loss_1se
	)

	elastic_net_log_loss_pct <<- elastic_net_grid %>%
		select_by_pct_loss(metric = 'mn_log_loss', desc(penalty))
	final_elastic_net_log_loss_pct <<- finalize_workflow(
		elastic_net_workflow,
		elastic_net_log_loss_pct
	)
}

jgn_regularization_summary_table <- function(fit_type = 'lasso', fit_name = 'max', metric = 'roc_auc'){
	if(metric == 'roc_auc'){
		metric_display <- 'AUC'
		metric_varname <- metric_display %>% str_to_lower()
	}

	if(metric == 'accuracy'){
		metric_display <- 'Accuracy'
		metric_varname <- metric_display %>% str_to_lower()
	}

	if(metric == 'mn_log_loss'){
		metric_display <- 'Mean Log Loss'
		metric_varname <- 'log_loss'
	}

	result_grid <- get(paste0(fit_type, '_grid'))
	result_workflow <- get(paste0('final_', fit_type, '_', metric_varname, '_', fit_name))
	recipe <- get('lasso_recipe')

	if(fit_name == 'max'){
		fit_display = '$\\lambda_{min}$'
		fit <- result_grid %>% select_best(metric = metric)
	}

	if(fit_name == '1se'){
		fit_display = '$\\lambda_{1se}$'
		fit <- result_grid %>% select_by_one_std_err(metric = metric, desc(penalty))
	}

	if(fit_name == 'pct'){
		fit_display = '$\\lambda_{pct}$'
		fit <- result_grid %>% select_by_pct_loss(metric = metric, desc(penalty))
	}

	final_fit <- last_fit(
		result_workflow,
		lasso_split,
		metrics = lasso_metrics
	)

	fit_nzero <- final_fit %>%
		extract_fit_parsnip() %>%
		vi(lambda = fit$penalty) %>%
		filter(Importance != 0) %>%
		nrow()

	fit_metric <- final_fit %>%
		collect_metrics() %>%
		filter(.metric == metric) %>%
		pull(.estimate)

	if('mixture' %in% colnames(fit)){
		alpha <- fit$mixture
	} else {
		alpha = 1
	}

	cv_folds <- result_grid %>%
		show_best(metric = 'roc_auc', n = 1) %>%
		pull(n)

	cv_folds_display <- paste0('$n = ', cv_folds, '$')

	candidate_coefficients = (recipe %>% prep())$term_info %>%
		filter(role == 'predictor') %>%
		nrow()

	output <- tibble(
		`Alpha` = alpha,
		`Fit Name` = fit_display,
		`Metric` = fit_metric,
		`Penalty` = fit$penalty,
		`Cross-Validation Folds` = cv_folds_display,
		`Non-Zero Coefficients` = fit_nzero,
		`Candidate Coefficients` = candidate_coefficients
	) %>%
		rename(
			!!paste0(metric_display) := Metric,
			!!fit_display := Penalty
		)

	output %>%
		printKable(output_format = 'markdown')
}

jgn_lasso_plot <- function(data = lasso_grid, plotly_enable = FALSE){
	measure_labels <- c('Accuracy', 'AUC', 'Mean Log Loss')
	names(measure_labels) <- c('accuracy', 'roc_auc', 'mn_log_loss')

	if(!plotly_enable){
		x_display <- latex2exp::TeX('Log ($\\lambda$)')
	} else {
		x_display <- 'Log Lambda'
	}

	p <- ggplot(
		data = data %>%
			collect_metrics() %>%
			mutate(
				.metric = .metric %>% factor(c('roc_auc', 'accuracy', 'mn_log_loss'))
			) %>%
			filter(!is.na(.metric)),
		aes(
			penalty,
			mean,
			color = .metric)
	) +
		geom_errorbar(
			aes(
				ymin = mean - std_err,
				ymax = mean + std_err
			),
			alpha = 0.5,
			width = 0.10
		) +
		geom_line() +
		geom_point() +
		lemon::facet_rep_wrap(
			~ .metric,
			scales = 'free',
			nrow = 3,
			labeller = labeller(.metric = measure_labels)
		) +
		scale_x_log10(breaks = trans_breaks('log10', function(x) 10^x),
									labels = trans_format('log10', math_format(.x))) +
		theme_jgn() +
		theme(legend.position = 'none') +
		scale_color_nejm() +
		labs(
			x = x_display,
			y = 'Mean'
		)

	if(plotly_enable){
		p %>% plotly::ggplotly()
	} else {
		p
	}
}

jgn_elastic_net_plot <- function(data = elastic_net_grid, range = 1, plotly_enable = FALSE){
	elastic_net_plot_df <- data %>%
		collect_metrics() %>%
		mutate(
			.metric = .metric %>% factor(c('roc_auc', 'accuracy', 'mn_log_loss')),
			mixture = mixture %>% factor()
		)

	levels(elastic_net_plot_df$.metric) <- c(
		'AUC', 'Accuracy', 'Mean Log Loss'
	)

	if(!plotly_enable){
		parse_engine <- label_parsed
		x_display <- latex2exp::TeX('Log ($\\lambda$)')
		levels(elastic_net_plot_df$mixture) <- c(
			latex2exp::TeX('$\\alpha = 0$'),
			latex2exp::TeX('$\\alpha = 0.11$'),
			latex2exp::TeX('$\\alpha = 0.22$'),
			latex2exp::TeX('$\\alpha = 0.33$'),
			latex2exp::TeX('$\\alpha = 0.44$'),
			latex2exp::TeX('$\\alpha = 0.55$'),
			latex2exp::TeX('$\\alpha = 0.66$'),
			latex2exp::TeX('$\\alpha = 0.77$'),
			latex2exp::TeX('$\\alpha = 0.88$'),
			latex2exp::TeX('$\\alpha = 1$')
		)
	} else {
		parse_engine <- label_value
		x_display <- 'Log Lambda'
		levels(elastic_net_plot_df$mixture) <- c(
			'0',
			'0.11',
			'0.22',
			'0.33',
			'0.44',
			'0.55',
			'0.66',
			'0.77',
			'0.88',
			'1'
		)
	}

	elastic_net_plot_df_1 <<- elastic_net_plot_df %>%
		filter(mixture %in% levels(mixture)[1:3])

	elastic_net_plot_df_2 <<- elastic_net_plot_df %>%
		filter(mixture %in% levels(mixture)[4:6])

	elastic_net_plot_df_3 <<- elastic_net_plot_df %>%
		filter(mixture %in% levels(mixture)[7:9])

	df_name <- paste0('elastic_net_plot_df_', range)

	df_pull <- get(df_name)

	p <- ggplot(
		data = df_pull %>%
			filter(!is.na(.metric)),
		aes(
			penalty,
			mean,
			color = .metric)
	) +
		geom_errorbar(
			aes(
				ymin = mean - std_err,
				ymax = mean + std_err
			),
			alpha = 0.5,
			width = 0.10
		) +
		geom_line() +
		geom_point() +
		lemon::facet_rep_grid(
			.metric ~ mixture,
			scales = 'free',
			labeller = labeller(.metric = label_value, mixture = parse_engine),
			repeat.tick.labels = TRUE
		) +
		scale_x_log10(breaks = trans_breaks('log10', function(x) 10^x),
									labels = trans_format('log10', math_format(.x))) +
		theme_jgn() +
		theme(
			legend.position = 'none'
		) +
		scale_color_nejm() +
		labs(
			x = x_display,
			y = 'Mean'
		)

	if(plotly_enable){
		p %>% plotly::ggplotly()
	} else {
		p
	}
}

jgn_importance_table <- function(fit_type = 'lasso', fit_name = 'max', metric = 'roc_auc', training_data = lasso_train){
  if(metric == 'roc_auc'){
    metric_display <- 'AUC'
    metric_varname <- metric_display %>% str_to_lower()
  }

  if(metric == 'accuracy'){
    metric_display <- 'Accuracy'
    metric_varname <- metric_display %>% str_to_lower()
  }

  if(metric == 'mn_log_loss'){
    metric_display <- 'Mean Log Loss'
    metric_varname <- 'log_loss'
  }

  result_grid <- get(paste0(fit_type, '_grid'))
  result_workflow <- get(paste0('final_', fit_type, '_', metric_varname, '_', fit_name))
  result_parameters <- get(paste0(fit_type, '_', metric_varname, '_', fit_name))

  importance_table <<- result_workflow %>%
    fit(training_data) %>%
    extract_fit_parsnip() %>%
    vi(lambda = result_parameters$penalty) %>%
    filter(Importance != 0) %>%
    mutate(
      Importance = Importance %>% abs(),
      Variable = Variable %>% fct_reorder(Importance),
      Sign = Sign %>% fct_recode(
        'Positive' = 'POS',
        'Negative' = 'NEG'
      )
    )

  importance_table %>%
  	print_kable() %>%
  	fmt_number(decimals = 8)
}

jgn_importance_table_shap <- function(fit_type = 'lasso', fit_name = 'max', metric = 'roc_auc', training_data = lasso_train){
	if(metric == 'roc_auc'){
		metric_display <- 'AUC'
		metric_varname <- metric_display %>% str_to_lower()
	}

	if(metric == 'accuracy'){
		metric_display <- 'Accuracy'
		metric_varname <- metric_display %>% str_to_lower()
	}

	if(metric == 'mn_log_loss'){
		metric_display <- 'Mean Log Loss'
		metric_varname <- 'log_loss'
	}

	result_grid <- get(paste0(fit_type, '_grid'))
	result_workflow <- get(paste0('final_', fit_type, '_', metric_varname, '_', fit_name))
	result_parameters <- get(paste0(fit_type, '_', metric_varname, '_', fit_name))

	importance_table_shap <<- (result_workflow %>%
		fit(training_data) %>%
		extract_fit_parsnip())$fit %>%
		vi_shap(
			train = lasso_recipe %>%
				prep() %>%
				juice() %>%
				data.matrix(),
			pred_wrapper = function(object, newdata){
				predict(object, newx = newdata, s = result_parameters$penalty)[,1]
			}
		) %>%
		filter(Importance != 0) %>%
		arrange(desc(Importance))

	importance_table_shap %>%
		print_kable() %>%
		fmt_number(decimals = 8)
}

jgn_importance_plot <- function(){
  importance_table %>% ggplot(
    aes(
      x = Importance,
      y = Variable,
      fill = Sign
    )
  ) +
    geom_col() +
    theme_jgn() +
    scale_fill_nejm() +
    labs(
      y = NULL
    )
}

jgn_importance_plot_shap <- function(fill_set = pal_nejm()(3)[3]){
  importance_table_shap %>%
		ggplot(
	    aes(
	      x = Importance,
	      y = reorder(Variable, Importance)
	    )
	  ) +
	    geom_col(fill = fill_set) +
	    theme_jgn() +
	    labs(
	      x = 'mean(|Shapley Value|)',
	      y = NULL
	    )
}

jgn_lasso_enr_roc <- function(recipe = lasso_recipe, prediction_data = xgboost_predictions, positive = 2){
	outcome_varname <<- lasso_recipe$var_info %>% filter(role == 'outcome') %>% select(variable) %>% as.character()
	outcome <- recipe$template %>% pull(outcome_varname)
	positive_level_number <<- positive
	positive_level <<- ifelse(positive_level_number == 1, 'first', 'second')
	positive_value <<- levels(outcome)[positive_level_number]

	lasso_enr_roc <<- roc(
		response = prediction_data %>% pull(outcome_varname),
		predictor = prediction_data %>% pull(paste0('.pred_', positive_value)),
		ci = TRUE,
		levels = c(
			setdiff(levels(outcome), positive_value),
			positive_value
		)
	)

	lasso_enr_roc %>%
		jggroc()
}

jgn_xgboost <- function(recipe = xgboost_recipe, metric_select = 'roc_auc', positive = 2, gamma_param = NA, tree_set = NA, folds = xgboost_folds, grid_size = 30, split_set = xgboost_split, train_data = xgboost_train){
	outcome_varname <<- recipe$var_info %>% filter(role == 'outcome') %>% select(variable) %>% as.character()
	outcome <- recipe$template %>% pull(outcome_varname)
	positive_level_number <<- positive
	positive_level <<- ifelse(positive_level_number == 1, 'first', 'second')
	positive <<- levels(outcome)[positive_level_number]
	selected_metric <<- metric_select
	metric_display_names<- tribble(
		~metric_name, ~display_name,
		'roc_auc', 'AUC',
		'accuracy', 'Accuracy',
		'mn_log_loss', 'Mean Log Loss'
	)
	selected_metric_display <<- metric_display_names %>% filter(metric_name == selected_metric) %>% pull(display_name)

	if(!is.na(gamma_param)){
		gamma_parameter <<- gamma_param

		if(!is.na(tree_set)){
			num_trees <<- tree_set

			xgboost_spec <<-
				boost_tree(
					trees = tree_set,
					tree_depth = tune(), min_n = tune(),
					loss_reduction = gamma_param,        ## first three: model complexity
					sample_size = tune(), mtry = tune(), ## randomness
					learn_rate = tune()                  ## step_size
				) %>%
				set_mode('classification') %>%
				set_engine('xgboost')
		} else {
			xgboost_spec <<-
				boost_tree(
					trees = tune(),
					tree_depth = tune(), min_n = tune(),
					loss_reduction = gamma_param,        ## first three: model complexity
					sample_size = tune(), mtry = tune(), ## randomness
					learn_rate = tune()                  ## step_size
				) %>%
				set_mode('classification') %>%
				set_engine('xgboost')
		}
	} else {
		if(!is.na(tree_set)){
			num_trees <<- tree_set

			xgboost_spec <<-
				boost_tree(
					trees = tree_set,
					tree_depth = tune(), min_n = tune(),
					loss_reduction = tune(),             ## first three: model complexity
					sample_size = tune(), mtry = tune(), ## randomness
					learn_rate = tune()                  ## step_size
				) %>%
				set_mode('classification') %>%
				set_engine('xgboost')
		} else {
			xgboost_spec <<-
				boost_tree(
					trees = tune(),
					tree_depth = tune(), min_n = tune(),
					loss_reduction = tune(),             ## first three: model complexity
					sample_size = tune(), mtry = tune(), ## randomness
					learn_rate = tune()                  ## step_size
				) %>%
				set_mode('classification') %>%
				set_engine('xgboost')
		}
	}

	xgboost_workflow <<-
		workflow() %>%
		add_recipe(recipe) %>%
		add_model(xgboost_spec)

	# Parallel Processing
	doParallel::registerDoParallel()

	set.seed(345)
	xgboost_tune <<- tune_race_anova(
		xgboost_workflow,
		resamples = folds,
		grid = grid_size,
		metrics = metric_set(roc_auc, pr_auc, accuracy, bal_accuracy, kap, mcc, mn_log_loss),
		control = control_race(
			verbose_elim = TRUE,
			save_pred = TRUE,
			event_level = positive_level
		)
	)

	xgboost_best <<- xgboost_tune %>%
		select_best(metric = metric_select)

	xgboost_finalized_workflow <<- xgboost_workflow %>%
		finalize_workflow(xgboost_best)

	xgboost_last_fit <<- xgboost_finalized_workflow %>%
		last_fit(
			split = split_set,
			metrics = metric_set(roc_auc, pr_auc, accuracy, bal_accuracy, kap, mcc, mn_log_loss),
			control = control_last_fit(
				allow_par = TRUE,
				event_level = positive_level
			)
		)

	xgboost_metrics <<- xgboost_last_fit %>%
		collect_metrics()

	xgboost_predictions <<- xgboost_last_fit %>%
		collect_predictions()

	xgboost_fit <<- xgboost_finalized_workflow %>%
		fit(data = train_data)

	xgboost_fit_resamples <<- xgboost_finalized_workflow %>%
		fit_resamples(
			resamples = folds,
			metrics = metric_set(roc_auc, pr_auc, accuracy, bal_accuracy, kap, mcc, mn_log_loss),
			control = control_resamples(
				save_pred = TRUE,
				event_level = positive_level
			)
		)
}

jgn_xgboost_summary_table <- function(best_fit = xgboost_best, num_trees_set = num_trees, folds = xgboost_folds, metric_set_display = selected_metric_display, gamma_param_set = 'gamma_parameter', n_sigfig_set = 6){
	if('trees' %in% colnames(best_fit)){
		trees_display = best_fit$trees
	} else {
		trees_display = num_trees_set
	}

	cv_folds_display <<- paste0('n = ', folds$splits %>% length())

	output <- tibble(
		`Metric` = metric_set_display,
		`Cross-Validation Folds` = cv_folds_display,
		`Trees` = trees_display,
		`Tree Depth` = best_fit$tree_depth,
		`Minimal Node Size` = best_fit$min_n,
		`Proportion Observations Sampled` = best_fit$sample_size,
		`Randomly Selected Predictors` = best_fit$mtry,
		`Learning Rate` = best_fit$learn_rate
	)

	if(exists(gamma_param_set)){
		output <- output %>% mutate(
			`Minimum Loss Reduction` = get(gamma_param_set),
		) %>%
			relocate(`Minimum Loss Reduction`, .after = `Minimal Node Size`)
	} else {
		output <- output %>% mutate(
			`Minimum Loss Reduction` = best_fit$loss_reduction,
		) %>%
			relocate(`Minimum Loss Reduction`, .after = `Minimal Node Size`)
	}

	output %>%
		print_kable() %>%
		fmt_number(
			columns = one_of('Learning Rate', 'Proportion Observations Sampled'),
			n_sigfig = n_sigfig_set
		) %>%
		fmt_number(
			columns = one_of('Trees', 'Randomly Selected Predictors', 'Minimal Node Size', 'Tree Depth', 'Minimum Loss Reduction'),
			decimals = 0
		)
}

jgn_xgboost_confusion_matrix <- function(prediction_data = xgboost_predictions, outcome_variable = outcome_varname, positive_level_num = positive_level_number, n_sigfig_set = 6){
	# From: https://stackoverflow.com/questions/64464321/getting-error-on-using-caretconfusionmatrix-on-collect-predictions-from-ti
	outcome <<- prediction_data %>% pull(outcome_variable)

	output <- caret::confusionMatrix(
		prediction_data %>% pull(.pred_class),
		prediction_data %>% pull(outcome_variable),
		positive = levels(outcome)[positive_level_num]
	) %>%
		tidy()

	outcome_prevalence <<- output %>% filter(term == 'prevalence') %>% pull(estimate)

	output %>%
		print_kable() %>%
		fmt_number(
			columns = one_of('estimate', 'conf.low', 'conf.high'),
			n_sigfig = n_sigfig_set
		)
}

jgn_xgboost_roc <- function(prediction_data = xgboost_predictions, outcome_variable = outcome_varname, positive_label = positive){
	xgboost_roc <<- roc(
		response = prediction_data %>% pull(outcome_variable),
		predictor = prediction_data %>% pull(paste0('.pred_', positive_label)),
		ci = TRUE,
		levels = c(
			setdiff(levels(outcome), positive_label),
			positive_label
		)
	)

	xgboost_roc %>%
		jggroc()
}

jgn_xgboost_prc <- function(predictions = xgboost_predictions, outcome_variable = outcome_varname, positive_label = positive, positive_level_label = positive_level, prevalence = outcome_prevalence, roc_data = xgboost_roc){
	auprc_print <- paste0(
		'AUC[PR]:',
		predictions %>%
			pr_auc(
				truth = outcome_variable,
				paste0('.pred_', positive_label),
				event_level = positive_level_label
			) %>%
			pull(.estimate) %>%
			signif(digits = 3)
	)

	outcome_prevalence_print <- paste0(
		'Prevalence: ', prevalence %>% signif(digits = 3)
	)
	xgboost_roc_coords <<- roc_data %>%
		pROC::coords('all', ret = c('threshold', 'precision', 'recall'))

	xgboost_roc_coords_ci <<- roc_data %>%
		ci.coords(xgboost_roc_coords$threshold, ret = c('precision', 'recall')) %>%
		as.data.frame() %>%
		as_tibble() %>%
		rename(
			precision_min = precision.2.5.,
			precision = precision.50.,
			precision_max = precision.97.5.,
			recall_min = recall.2.5.,
			recall = recall.50.,
			recall_max = recall.97.5.
		)

	ggplot(
		data = xgboost_roc_coords_ci,
		aes(
			x = recall,
			y = precision,
			ymin = precision_min,
			ymax = precision_max
		)
	) +
		geom_hline(yintercept = outcome_prevalence, color = pal_nejm()(2)[1], linetype = 'longdash') +
		geom_ribbon(
			fill = pal_nejm()(2)[2],
			color = 'gray',
			alpha = 0.2
		) +
		geom_line(color = 'black', alpha = 0.9) +
		theme_jgn() +
		labs(
			x = 'Recall',
			y = 'Precision'
		) +
		coord_equal(ylim = c(0, 1), xlim = c(0, 1)) +
		annotate('text', x = 1, y = 0.94, label = auprc_print, family = font, size = 5, hjust = 1.05, parse = TRUE) +
		annotate('text', x = 1, y = 0.82, label = outcome_prevalence_print, family = font, size = 5, hjust = 1.05)
}

# jgn_xgboost_calibration_plot <- function(resample_fit = xgboost_fit_resamples){
# 	resample_fit %>%
# 		cal_plot_windowed(
# 			truth = composite_outcome,
# 			estimate = paste0('.pred_', positive),
# 			conf_level = 0.95,
# 			event_level = positive_level
# 		) +
# 		theme_jgn() +
# 		theme(
# 			text = element_text(family = font, size = 14),
# 		) +
# 		labs(
# 			x = 'Predicted Probability',
# 			y = 'Empirical Probability'
# 		)
# }

jgn_xgboost_tuning_plot <- function(tuning_data = xgboost_tune, metric_selected = selected_metric, metric_selected_display = selected_metric_display){
	tuning_data %>%
		collect_metrics() %>%
		filter(.metric == metric_selected) %>%
		select(any_of(c('mean', 'trees', 'tree_depth', 'min_n', 'loss_reduction', 'sample_size', 'mtry', 'learn_rate'))) %>%
		pivot_longer(any_of(c('trees', 'tree_depth', 'min_n', 'loss_reduction', 'sample_size', 'mtry', 'learn_rate')), values_to = 'value', names_to = 'parameter') %>%
		ggplot(
			aes(
				x = value,
				y = mean,
				color = parameter
			)
		) +
		geom_point(alpha = 0.8) +
		facet_rep_wrap(. ~ parameter, scales = 'free_x') +
		labs(
			x = 'Parameter',
			y = metric_selected_display
		) +
		theme_jgn() +
		theme(
			legend.position = 'none'
		) +
		scale_color_nejm()
}

jgn_xgboost_race_plot <- function(tuning_data = xgboost_tune, metric_display = selected_metric_display){
	tuning_data %>%
		plot_race() +
		theme_jgn() +
		labs(
			y = metric_display
		)
}

jgn_xgboost_importance_table <- function(last_fit = xgboost_last_fit, num_decimals = 8){
	last_fit %>%
		extract_fit_parsnip() %>%
		vi() %>%
		filter(Importance != 0) %>%
		mutate(
			Importance = Importance,
			Variable = Variable %>% fct_reorder(Importance)
		) %>%
		print_kable() %>%
		fmt_number(decimals = num_decimals)
}

jgn_xgboost_importance_plot <- function(last_fit = xgboost_last_fit, fill_set = pal_nejm()(2)[2]){
	last_fit %>%
		extract_fit_parsnip() %>%
		vip(
			aesthetics = list(fill = fill_set)
		) +
		theme_jgn() +
		scale_fill_nejm() +
		scale_color_nejm() +
		labs(
			y = NULL
		)
}

jgn_xgboost_shap_prep <- function(recipe = xgboost_recipe, fit = xgboost_last_fit){
	# From: https://stackoverflow.com/questions/71662140/create-shap-plots-for-tidymodel-objects
	# And: https://www.hfshr.xyz/posts/2020-06-07-variable-importance-with-fastshap/
	vars_to_remove <<- c(
		recipe$var_info %>% filter(role == 'outcome') %>% select(variable) %>% as.character(),
		recipe$var_info %>% filter(role == 'ID') %>% select(variable) %>% as.character()
	) %>%
		setdiff(
			.,
			'character(0)'
		)

	xgboost_shap_x <<- recipe %>%
		prep() %>%
		juice() %>%
		select(-one_of(vars_to_remove)) %>%
		as.matrix()

	xgboost_explanations <<- fastshap::explain(
		(fit %>% extract_fit_parsnip())$fit,
		X = xgboost_shap_x,
		exact = TRUE
	)

	xgboost_shap <<- shapviz(
		xgboost_explanations,
		X = xgboost_shap_x
	)
}

jgn_xgboost_shap_waterfall_plot <- function(shap_data = xgboost_shap){
	shap_data %>%
		sv_waterfall() +
		theme_jgn() +
		scale_fill_manual(values = pal_nejm()(2) %>% rev())
}

jgn_xgboost_shap_force_plot <- function(shap_data = xgboost_shap){
	shap_data %>%
		sv_force() +
		theme_jgn() +
		scale_fill_manual(values = pal_nejm()(2) %>% rev())
}

jgn_xgboost_shap_dependence_plot <- function(shap_data = xgboost_shap, v_select = NA, color_var_select = NA){
	if(is.na(v_select) | is.na(color_var_select)){
		stop('`v_select` (column name of feature to be plotted) and `color_var_select` (feature name to be used on the color scale to investigate interactions) must be specified in function argument.')
	} else {
		shap_data %>%
			sv_dependence(v = v_select, color_var = color_var_select) +
			theme_jgn() +
			scale_fill_manual(values = pal_nejm()(2) %>% rev()) +
			labs(
				y = 'SHAP Value',
				x = big_data %>% pull(v_select) %>% var_label(),
				color = big_data %>% pull(color_var_select) %>% var_label()
			)
	}
}

jgn_xgboost_shap_importance_table <- function(last_fit = xgboost_last_fit, shap_x = xgboost_shap_x, num_decimals = 8){
	(last_fit %>%
	 	extract_fit_parsnip())$fit %>%
		vi(
			method = 'shap',
			train = shap_x,
			exact = TRUE
		) %>%
		filter(Importance != 0) %>%
		mutate(
			Importance = Importance,
			Variable = Variable %>% fct_reorder(Importance)
		) %>%
		print_kable() %>%
		fmt_number(decimals = num_decimals)
}

jgn_xgboost_shap_importance_plot <- function(shap_data = xgboost_shap, fill_set = pal_nejm()(3)[3]){
	shap_data %>%
		sv_importance(fill = fill_set) +
		theme_jgn()
}

jgn_xgboost_shap_importance_beeswarm_plot <- function(shap_data = xgboost_shap){
	shap_data %>%
		sv_importance(kind = 'beeswarm') +
		theme_jgn() +
		theme(legend.position = 'right')
}

jgn_xgboost_shap_importance_overlay_plot <- function(shap_data = xgboost_shap, fill_set = pal_nejm()(3)[3]){
	shap_data %>%
		sv_importance(kind = 'both', show_numbers = TRUE, alpha = 0.2, fill = fill_set, color_bar_title = 'Feature Value') +
		theme_jgn() +
		theme(legend.position = 'right') +
	labs(
			x = 'SHAP Value'
		)
}

jgn_xgboost_cleanup <- function(prefix = NA){
  if(is.na(prefix)){
  	stop('`prefix` is required to proceed.')
  }

	variables <- c(
  	# Variables defined manually
  	'xgboost_data',
  	'xgboost_split',
  	'xgboost_train',
  	'xgboost_test',
  	'xgboost_folds',
  	'xgboost_recipe',
		# Variables generated by `jgn_xgboost` function
  	'cv_folds_display',
  	'outcome',
  	'outcome_varname',
  	'positive',
  	'positive_level',
  	'positive_level_number',
  	'outcome_prevalence',
  	'selected_metric',
		'selected_metric_display',
  	'vars_to_remove',
  	'xgboost_best',
  	'xgboost_explanations',
		'xgboost_finalized_workflow',
  	'xgboost_fit',
  	'xgboost_fit_resamples',
  	'xgboost_last_fit',
  	'xgboost_metrics',
  	'xgboost_predictions',
  	'xgboost_roc',
  	'xgboost_roc_coords',
  	'xgboost_roc_coords_ci',
  	'xgboost_shap',
  	'xgboost_shap_x',
  	'xgboost_spec',
  	'xgboost_tune',
  	'xgboost_workflow'
  )

  if(exists('gamma_parameter')){
    variables <- c(
      'gamma_parameter',
      variables
    )
  }

  if(exists('num_trees')){
    variables <- c(
      'num_trees',
      variables
    )
  }

  walk(
    variables,
    ~assign(paste0(prefix, '_', .x), get(.x), get(.x), envir = .GlobalEnv)
  )

  rm(list = variables, envir = .GlobalEnv)
}

jgn_tidymodels_lasso_output_results <- function(base_heading = '#'){
	fit_type_set = 'lasso'

	metric_display_names<- tribble(
		~metric_name, ~display_name,
		'roc_auc', 'AUC',
		'accuracy', 'Accuracy',
		'mn_log_loss', 'Mean Log Loss'
	)

	fit_display_names <- tribble(
		~object_name, ~display_name,
		'max', 'min',
		'1se', '1se',
		'pct', 'pct'
	)

	iwalk(
		metric_display_names %>% pull(metric_name),
		function(.fit_metrics, .metric_name){
			metric_display_name <- metric_display_names %>%
				filter(metric_name == .fit_metrics) %>%
				pull(display_name)

			cat(base_heading, '# ', metric_display_name, '\n\n', sep = '')
			cat('<div class="panel-tabset">\n\n')

			iwalk(
				fit_display_names %>% pull(object_name),
				function(.fit_names, .fit_display_names){
					fit_display_name <- fit_display_names %>%
						filter(object_name == .fit_names) %>%
						pull(display_name)

					cat(base_heading, '## $\\lambda_{', fit_display_name, '}$\n\n', sep = '')
					cat('<div class="panel-tabset">\n\n')

					cat(base_heading, '### Summary Table\n\n', sep = '')

					jgn_regularization_summary_table(fit_type = fit_type_set, fit_name = .fit_names, metric = .fit_metrics) %>%
						print()

					cat(base_heading, '### Variable Importance\n\n', sep = '')

					cat('<div class="panel-tabset">\n\n')

					cat(base_heading, '### Table\n\n', sep = '')

					jgn_importance_table(fit_type = fit_type_set, fit_name = .fit_names, metric = .fit_metrics) %>%
						print()

					cat(base_heading, '### Plot\n\n', sep = '')

					jgn_importance_plot() %>%
						print()

					cat('</div>\n\n')

					cat(base_heading, '### Shapley Variable Importance\n\n', sep = '')

					cat('<div class="panel-tabset">\n\n')

					cat(base_heading, '### Table\n\n', sep = '')

					jgn_importance_table_shap(fit_type = fit_type_set, fit_name = .fit_names, metric = .fit_metrics) %>%
						print()

					cat(base_heading, '### Plot\n\n', sep = '')

					jgn_importance_plot_shap() %>%
						print()

					cat('</div>\n\n')


					cat('</div>\n\n')
				}
			)


			cat('</div>\n\n')
		}
	)

	cat(base_heading, '# Regularization Parameter Plot\n\n', sep = '')

	# cat('<div class="panel-tabset">\n\n')

	# cat(base_heading, '### Static\n\n', sep = '')

	jgn_lasso_plot() %>%
		print()

	# cat(base_heading, '### Dynamic\n\n', sep = '')

	# jgn_lasso_plot(plotly_enable = TRUE) %>%
	#   print()

	# cat('</div>\n\n')
}

jgn_tidymodels_elastic_net_output_results <- function(base_heading = '#'){
	fit_type_set = 'elastic_net'

	metric_display_names<- tribble(
		~metric_name, ~display_name,
		'roc_auc', 'AUC',
		'accuracy', 'Accuracy',
		'mn_log_loss', 'Mean Log Loss'
	)

	fit_display_names <- tribble(
		~object_name, ~display_name,
		'max', 'min',
		'1se', '1se',
		'pct', 'pct'
	)

	iwalk(
		metric_display_names %>% pull(metric_name),
		function(.fit_metrics, .metric_name){
			metric_display_name <- metric_display_names %>%
				filter(metric_name == .fit_metrics) %>%
				pull(display_name)

			cat(base_heading, '# ', metric_display_name, '\n\n', sep = '')
			cat('<div class="panel-tabset">\n\n')

			iwalk(
				fit_display_names %>% pull(object_name),
				function(.fit_names, .fit_display_names){
					fit_display_name <- fit_display_names %>%
						filter(object_name == .fit_names) %>%
						pull(display_name)

					cat(base_heading, '## $\\lambda_{', fit_display_name, '}$\n\n', sep = '')
					cat('<div class="panel-tabset">\n\n')

					cat(base_heading, '### Summary Table\n\n', sep = '')

					jgn_regularization_summary_table(fit_type = fit_type_set, fit_name = .fit_names, metric = .fit_metrics) %>%
						print()

					cat(base_heading, '### Variable Importance\n\n', sep = '')

					cat('<div class="panel-tabset">\n\n')

					cat(base_heading, '### Table\n\n', sep = '')

					jgn_importance_table(fit_type = fit_type_set, fit_name = .fit_names, metric = .fit_metrics) %>%
						print()

					cat(base_heading, '### Plot\n\n', sep = '')

					jgn_importance_plot() %>%
						print()

					cat('</div>\n\n')

					cat(base_heading, '### Shapley Variable Importance\n\n', sep = '')

					cat('<div class="panel-tabset">\n\n')

					cat(base_heading, '### Table\n\n', sep = '')

					jgn_importance_table_shap(fit_type = fit_type_set, fit_name = .fit_names, metric = .fit_metrics) %>%
						print()

					cat(base_heading, '### Plot\n\n', sep = '')

					jgn_importance_plot_shap() %>%
						print()

					cat('</div>\n\n')


					cat('</div>\n\n')
				}
			)


			cat('</div>\n\n')
		}
	)

	cat(base_heading, '# Regularization Parameter Plot\n\n', sep = '')

	cat('<div class="panel-tabset">\n\n')

	cat(base_heading, '## $\\alpha = [0, 0.22]$\n\n', sep = '')

	jgn_elastic_net_plot(range = 1) %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '## $\\alpha = [0.33, 0.55]$\n\n', sep = '')

	jgn_elastic_net_plot(range = 2) %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '## $\\alpha = [0.66, 0.88]$\n\n', sep = '')

	jgn_elastic_net_plot(range = 3) %>%
		print()

	cat('</div>\n\n')

	# cat('<div class="panel-tabset">\n\n')

	# cat(base_heading, '### Static\n\n', sep = '')

	# cat(base_heading, '### Dynamic\n\n', sep = '')

	# cat('</div>\n\n')
}

jgn_tidymodels_xgboost_output_results <- function(base_heading = '#'){

	cat(base_heading, '# Summary Table\n\n', sep = '')

	jgn_xgboost_summary_table() %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '# Confusion Matrix\n\n', sep = '')

	jgn_xgboost_confusion_matrix() %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '# AUROC\n\n', sep = '')

	jgn_xgboost_roc() %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '# AUPRC\n\n', sep = '')

	jgn_xgboost_prc() %>%
		print()

	# cat('\n\n', sep = '')
	# cat(base_heading, '# Calibration Plot\n\n', sep = '')
	#
	# (xgboost_fit_resamples %>%
	# 		cal_plot_windowed(
	# 			truth = composite_outcome,
	# 			estimate = paste0('.pred_', positive),
	# 			conf_level = 0.95,
	# 			event_level = positive_level
	# 		) +
	# 		theme_jgn() +
	# 		theme(
	# 			text = element_text(family = font, size = 14),
	# 		) +
	# 		labs(
	# 			x = 'Predicted Probability',
	# 			y = 'Empirical Probability'
	# 		)) %>%
	# 	print()

	cat('\n\n', sep = '')
	cat(base_heading, '# Parameter Tuning Plot\n\n', sep = '')

	jgn_xgboost_tuning_plot() %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '# Race Plot\n\n', sep = '')

	jgn_xgboost_race_plot() %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '# Variable Importance\n\n', sep = '')

	cat('\n\n', sep = '')
	cat('<div class="panel-tabset">\n\n')

	cat('\n\n', sep = '')
	cat(base_heading, '## Table\n\n', sep = '')

	jgn_xgboost_importance_table() %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '## Plot\n\n', sep = '')

	jgn_xgboost_importance_plot() %>%
		print()

	cat('\n\n', sep = '')
	cat('</div>\n\n')

	cat('\n\n', sep = '')
	cat(base_heading, '# Shapley Additive Explanations\n\n', sep = '')

	jgn_xgboost_shap_prep()

	cat('\n\n', sep = '')
	cat('<div class="panel-tabset">\n\n')

	# cat('\n\n', sep = '')
	# cat(base_heading, '## Waterfall Plot\n\n', sep = '')
	#
	# jgn_xgboost_shap_waterfall_plot() %>%
	# 	print()
	#
	# cat('\n\n', sep = '')
	# cat(base_heading, '## Force Plot\n\n', sep = '')
	#
	# jgn_xgboost_shap_force_plot() %>%
	# 	print()

	cat('\n\n', sep = '')
	cat(base_heading, '## Shapley Importance\n\n', sep = '')

	cat('\n\n', sep = '')
	cat('<div class="panel-tabset">\n\n')

	cat('\n\n', sep = '')
	cat(base_heading, '## Table\n\n', sep = '')

	jgn_xgboost_shap_importance_table() %>%
		print()

	cat('\n\n', sep = '')
	cat(base_heading, '## Plot\n\n', sep = '')

	jgn_xgboost_shap_importance_plot() %>%
		print()

	cat('\n\n', sep = '')
	cat('</div>\n\n')

	cat('\n\n', sep = '')
	cat(base_heading, '## Beeswarm Plot\n\n', sep = '')

	jgn_xgboost_shap_importance_beeswarm_plot() %>%
		print()

	# cat('\n\n', sep = '')
	# cat(base_heading, '## Shapley Importance Overlay\n\n', sep = '')
	#
	# jgn_xgboost_shap_importance_overlay_plot() %>%
	# 	print()

	cat('</div>\n\n')
}
