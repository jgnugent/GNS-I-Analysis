# Styling for kable output of dataframes and tibbles
printKable <- function(data, p_accuracy = 0.001, bold_p = FALSE, underline = FALSE, underline_column = 1, font_spec = NULL, font_size = NULL, ...){
	require(dplyr, warn.conflicts = FALSE, quietly = TRUE)

	if(tibble::is_tibble(data) | is.data.frame(data)){
		data <- data %>%
			mutate(
				across(
					matches('p.value'),
					~scales::pvalue(.x, accuracy = p_accuracy)
				)
			)

		if('p.value' %in% colnames(data) & 'conf.high' %in% colnames(data)){
			data <- data %>%
				relocate(
					p.value, .after = conf.high
				)
		}
	} else {
		data <- data %>%
			tibble::as_tibble()
	}

	output <- data

	output <- output %>%
		kableExtra::kbl(booktabs = TRUE, ...) %>%
		kableExtra::kable_styling(
			latex_options = c('striped','scale_down','hold_position'),
			bootstrap_options = c('striped', 'hover','condensed'),
			full_width = FALSE,
			fixed_thead = TRUE
		)

	if(!rlang::is_empty(font_spec)){
		output <- output %>%
			kableExtra::kable_styling(
				html_font = font_spec
			)
	}

	if(!rlang::is_empty(font_size)){
		output <- output %>%
			kableExtra::kable_styling(
				font_size = font_size
			)
	}
	if(underline){
		output <- output %>%
			kableExtra::column_spec(underline_column, underline = TRUE)
	}

	if(bold_p){
		p_column <- data %>%
			select(
				matches('p.value')
			) %>%
			colnames() %>%
			purrr::pluck(1)

		if(!rlang::is_empty(p_column)){
			p_column_num <- which(colnames(data) == p_column)

			output <- output %>%
				kableExtra::column_spec(
					p_column_num,
					bold = purrr::map_lgl(
						data %>% pull(p_column),
						~case_when(
							stringr::str_detect(.x, '<') ~ TRUE,
							!rlang::is_empty(.x) & as.numeric(.x) < 0.05 ~ TRUE,
							.default = FALSE
						)
					)
				)
		}
	}

	return(output)
}

# Can also just use `R` `as.character()` function
remove_trailing_zeros <- function(x){
	if(!is.character(x)){
		x <- x %>% as.character()
	}

	x %>%
		stringr::str_remove('\\.0+$')
}

remove_leading_zeros <- function(x){
	if(!is.character(x)){
		x <- x %>% as.character()
	}

	x %>%
		stringr::str_remove('^0+')
}

# Style for TableOne output
printKableOne <- function(data, column_names = NULL, comma = TRUE, bold = TRUE, underline = TRUE, n_percent_row = TRUE, strip_nonpara_trailing = TRUE, adorn_footnotes = FALSE, ...){
	output <- data %>%
		as_tibble(rownames = 'Variable')

	if(ncol(output) != 2 & n_percent_row){
		n_row <- output %>% filter(Variable == 'n') %>%
			mutate(
				across(
					!one_of('Variable', 'level', 'p', 'test'),
					~(.x %>% str_replace_all('[^0-9]', '') %>% as.numeric)
				),
			)

			n_percent <- n_row %>%
				mutate(
					Variable = 'n (%)',
					Overall = Overall %>% as.character(),
					across(
						!one_of('Variable', 'level', 'Overall', 'p', 'test'),
						~(
							paste0(.x %>% as.numeric(), ' (', scales::percent(
								(.x %>% as.numeric)/(n_row %>% pull(Overall) %>% as.numeric),
								accuracy = 0.1, suffix = ''), ')')
						)
					)
				)
	}

	if(n_percent_row){
		output <- bind_rows(
			n_percent,
			output %>%
				filter(Variable != 'n')
		)
	}

	if(comma){
		output <- output %>%
			tableone_style(strip_nonpara_trailing = strip_nonpara_trailing)
	}

	if(ncol(output) == 2){
		column_names = c(
			'Variable',
			'Level',
			'Total'
		)
	} else {
		if(is.null(column_names)){
			column_names = output %>%
				colnames() %>%
				replace(. == 'level', 'Level') %>%
				replace(. == 'Overall', 'Total') %>%
				replace(. == 'p', 'p-value') %>%
				replace(. == 'test', 'Test')
		} else {
			column_names = c(
				'Variable',
				'Level',
				'Total',
				column_names,
				'p-value',
				'Test'
			)
		}
	}

	if('p' %in% colnames(output)){
		p_col <- which(colnames(output) == 'p')

		output <- output %>%
			rowwise() %>%
			mutate(
				p = case_when(
					p %>% str_detect('<') ~ p,
					p %>% str_detect('>') ~ p,
					TRUE ~ p %>% as.numeric() %>% scales::pvalue(accuracy = 0.001)
				)
			) %>%
			ungroup()
	}

	output_print <- output %>%
		printKable(col.names = column_names, ...)

	if(bold){
		output_print <- output_print %>%
			column_spec(1, bold = TRUE)
	}

	if(underline){
		output_print <- output_print %>%
			column_spec(2, underline = TRUE)
	}

	if('p' %in% colnames(output)){
		output_print <- output_print %>%
			remove_column(which(colnames(output) == 'test')) %>%
			column_spec(p_col, bold = map_lgl(
				output %>% pull(p),
				~case_when(
					str_detect(.x, '<') ~ TRUE,
					!is_empty(.x) & as.numeric(.x) < 0.05 ~ TRUE,
					.default = FALSE
				)
			))
	}

	if(adorn_footnotes){
		output_print <- output_print %>%
			add_footnote(
				c(
					'<em>Dichotomous and categorical variables are presented as count (%). Normally distributed continuous variables are presented as mean (standard deviation), while non-normally distributed continuous variables are displayed as median [IQR].</em>',
					'<em><strong>Bolded</strong> entries in the p-value column indicate statistical significance at p < 0.05.</em>'
				),
				notation = 'none',
				escape = FALSE
			)
	}

	return(output_print)
}

# Styling for finalfit package output
printKableFit <- function(data, dash_substitution = '–', add_space = TRUE, comma_percent_columns = NULL, remove_levels_cont = TRUE, remove_columns = NULL, ...){
	output <- data

	if('Total' %in% colnames(data)){
		output <- data %>%
			rename(
				`n (%)` = Total
			)
	}

	if('all' %in% colnames(data)){
		output <- data %>%
			rename(
				`n (%)` = all
			)
	}

	output <- output %>%
		as_tibble() %>%
		rename(
			Variable = label,
			Level = levels
		) %>%
		mutate(
			Level = case_when(
				str_detect(`n (%)`, '100.0') ~ paste0('Range: ', str_replace(Level, ',', ', ')),
				TRUE ~ Level
				),
			`n (%)` = `n (%)` %>% str_replace_all(' \\(100.0\\)', '')
		) %>%
		mutate(
			across(
				everything(),
				~case_when(
					.x == '-' ~ 'Reference',
					.default = .x
				)
			),
			across(
				everything(),
				~(
					.x %>%
						str_replace_all('=', ' = ') %>%
						str_replace_all('<', ' < ') %>%
						str_replace_all('>', ' > ')
				)
			)
		) %>%
		select(-one_of('unit', 'value')) %>%
		dplyr::arrange()

	comma_percent_columns <- c(
		output %>%
			select(Level:`n (%)`) %>%
			names() %>%
			setdiff(., 'Level'),
		comma_percent_columns
	)

	output <- output %>%
		rowwise() %>%
		mutate(
			across(
				one_of(comma_percent_columns),
				~case_when(
					str_detect(Level, 'Range') | Level %in% c('Mean (SD)', 'Median (IQR)') ~ adorn_commas(.x, round_digits = 0),
					.default = adorn_commas(.x, no_round_n = TRUE)
				)
			)
		) %>%
		ungroup() %>%
		mutate(
			across(
				one_of(comma_percent_columns),
				~str_replace(.x, '\\)', '%\\)')
			),
			across(
				!one_of('Variable', 'Level', comma_percent_columns),
				~case_when(
					str_detect(.x, 'to') | !add_space ~ .x %>%
						str_replace_all('-', dash_substitution),
					.default = .x %>%
						str_replace_all('-', paste0(' ', dash_substitution, ' '))
				)
			)
		)

	if(remove_levels_cont){
		output <- output %>%
			mutate(
				across(
					one_of('Level', comma_percent_columns),
					~case_when(
						str_detect(Level, 'Range') | Level %in% c('Mean (SD)', 'Median (IQR)') ~ '',
						.default = .x
					)
				)
			)
	}

	output <- output %>%
		select(-one_of(remove_columns)) %>%
		printKable(...) %>%
    column_spec(1, bold = TRUE) %>%
    column_spec(2, underline = TRUE)

		return(output)
}

printSkimKable <- function(data){
	if(!'skim_list' %in% class(data)){
  	data <- data %>%
  		skimr::partition()
  }

	purrr::walk2(
		data,
		data %>% names(),
		~(
			printKable(
				.x %>%
					mutate_at(vars(one_of('n_missing', 'n_unique')), ~scales::comma(., accuracy = 1)) %>%
					mutate_at(vars(one_of('complete_rate')), ~scales::comma(., accuracy = .001)) %>%
					mutate_if(is.numeric, ~scales::comma(., accuracy = 0.01)),
				caption = paste0('Skim Type: ', .y)
			) %>%
				print()
		)
	)
}

print_kable <- function(data, p_accuracy = 0.001, bold_p = FALSE, underline = FALSE, underline_column = 1, font_spec = gt::google_font(name = 'EB Garamond'), format_escape = TRUE, remove_id = TRUE, copy_paste = FALSE, ...){
	require(dplyr, warn.conflicts = FALSE, quietly = TRUE)

	p_columns <- c('p', 'p-value', 'p.value', 'Log-Rank p-value', 'Test for Trend p-value')

	if(tibble::is_tibble(data) | is.data.frame(data)){
		data <- data %>%
			mutate(
				across(
					(one_of(p_columns) | matches('p.value')) & !where(is.character),
					~scales::pvalue(.x, accuracy = p_accuracy)
				)
			)

		if('p.value' %in% colnames(data) & 'conf.high' %in% colnames(data)){
			data <- data %>%
				relocate(p.value, .after = conf.high)
		}
	} else {
		if(remove_id == TRUE){
			data <- data %>%
				tibble::as_tibble()
		} else {
			data <- data %>%
				tibble::as_tibble(rownames = 'Variable')
		}
	}

	if(copy_paste == TRUE){
		if(ncol(data) == 1 & colnames(data) == 'value'){
			data <- data %>%
				mutate(
					value = case_when(
						row_number() == n() ~ paste0('\'', value, '\''),
						.default = paste0('\'', value, '\',')
					)
				)
		}
	}

	output <- data

	if(format_escape){
		output <- output %>%
			mutate(
				across(
					where(is.character) & !one_of('p') & !contains(p_columns),
					~htmltools::htmlEscape(.)
				),
				across(
					where(is.character) & !one_of('p') & !contains(p_columns),
					~str_replace_all(., '&lt;', '<')
				),
				across(
					where(is.character) & !one_of('p') & !contains(p_columns),
					~str_replace_all(., '&gt;', '>')
				)
			)
	}

	output <- output %>%
		gt() %>%
		cols_label_with(
			fn = ~paste0('<strong>', .x, '</strong>') %>% gt::html()
		) %>%
		tab_options(
			table.font.color = 'black',
			table.font.color.light = 'black',
			column_labels.border.top.color = 'black',
			column_labels.border.bottom.color = 'black',
			table.border.bottom.color = 'black',
			table_body.border.bottom.color = 'black',
			footnotes.border.bottom.color = 'black',
			quarto.use_bootstrap = TRUE
		) %>%
		opt_css(
			css = '
        .gt_table tbody tr:nth-of-type(odd) {
          background-color: rgba(0, 0, 0, 0.05);
        }
        .gt_table tbody tr:hover {
          background-color: rgba(0, 0, 0, 0.075);
        }
        .gt_caption {
          margin-bottom: 10px;
        }
        '
		) %>%
		sub_missing(
			columns = everything(),
			missing_text = ''
		) %>%
		cols_align(align = 'left')

	if(rstudioapi::isAvailable()){
		output <- output %>%
			opt_table_font(font_spec)
	}

	if(underline){
		if(underline_column %>% is.numeric()){
			output <- output %>%
				tab_style(
					style = cell_text(decorate = 'underline'),
					locations = cells_body(columns = names(data)[underline_column])
				)
		} else {
			output <- output %>%
				tab_style(
					style = cell_text(decorate = 'underline'),
					locations = cells_body(columns = underline_column)
				)
		}
	}

	if(bold_p){
		p_col <- data %>%
			select(
				one_of(p_columns)
			) %>%
			colnames()

		if(!rlang::is_empty(p_col)){
			output <- output %>%
				tab_style(
					style = cell_text(weight = 'bold'),
					locations = cells_body(
						columns = matches(p_col),
						rows = get(p_col) %>% str_remove('>') %>% str_remove('<') %>% as.numeric() < 0.05
					)
				)
		}

	}

	# if(copy_paste != TRUE){
	# 	output <- output %>%
	# 		fmt_markdown(
	# 			columns = c(1, one_of('Variable', 'Level'))
	# 		) %>%
	# 		cols_label_with(
	# 			fn = md
	# 		)
	# }

	return(output)
}

pretty_print <- function(x, round_digits = 0){
	x %>%
		as.numeric() %>%
		format(big.mark = ',', nsmall = round_digits)
}

adorn_commas <- function(x, round_digits = 2, no_round_n = FALSE, strip_nonpara_trailing = FALSE){
	if(no_round_n){
		round_digits = 0
	}

	if(!(x %>% as.numeric %>% is.na)){
		output <- x %>%
			pretty_print(round_digits = round_digits)
	} else {
		string_base <- x %>% str_remove(' ')

		string_cont_per <- string_base %>% strsplit(split = '\\(') %>% pluck(1)

		if(string_cont_per %>% length == 2){
			set_1 <- string_cont_per %>%
				pluck(1)

			set_2 <- string_cont_per %>%
				pluck(2) %>%
				str_remove('\\)')
		}

		string_cont_nonpara <- string_base %>% strsplit(split = '\\[') %>% pluck(1)

		if(string_cont_nonpara %>% length == 2){
			set_1 <- string_cont_nonpara %>%
				pluck(1)

			set_2_3 <- string_cont_nonpara %>%
				pluck(2) %>%
				strsplit(split = ',') %>%
				pluck(1)

			set_2 <- set_2_3 %>%
				pluck(1)

			set_3 <- set_2_3 %>%
				pluck(2) %>%
				str_remove('\\]')
		}

		set1_out <- set_1 %>%
			pretty_print(round_digits = round_digits)

		set2_out <- set_2 %>%
			pretty_print(round_digits = round_digits)

		if(exists('set_3')){
			set3_out <- set_3 %>%
				pretty_print(round_digits = round_digits)

			if(strip_nonpara_trailing){
				set1_out <- set_1 %>%
					pretty_print()

				set2_out <- set_2 %>%
					pretty_print()

				set3_out <- set_3 %>%
					pretty_print()
			}

			output <- paste0(set1_out, ' [', set2_out, ' – ', set3_out, ']')
		} else {
			output <- paste0(set1_out, ' (', set2_out, ')')
		}

	}

	return(output)
}

tableone_style <- function(tableone, affix_percent = TRUE, strip_nonpara_trailing = FALSE, override_rows = NULL){
	columns <- tableone %>%
		select(
			-one_of('Variable', 'Level', 'level', 'p', 'p-value', 'test')
		) %>%
		names()

	if(tableone %>% select(one_of('Level')) %>% ncol() != 0){
		tableone_out <- tableone %>%
			rowwise() %>%
			mutate(
				across(
					one_of(columns),
					~case_when(
						Variable %in% c('n', 'n (%)') ~ adorn_commas(.x, round_digits = 0),
						Variable %in% override_rows ~ adorn_commas(.x, no_round_n = TRUE),
						Level != '' ~ adorn_commas(.x, no_round_n = TRUE),
						.default = adorn_commas(.x, round_digits = 2, strip_nonpara_trailing = strip_nonpara_trailing)
					)
				)
			) %>%
			ungroup()
	} else {
		tableone_out <- tableone %>%
			rowwise() %>%
			mutate(
				across(
					one_of(columns),
					~case_when(
						Variable %in% c('n', 'n (%)') ~ adorn_commas(.x, round_digits = 0),
						Variable %in% override_rows ~ adorn_commas(.x, no_round_n = TRUE),
						.default = adorn_commas(.x, round_digits = 2, strip_nonpara_trailing = strip_nonpara_trailing)
					)
				)
			) %>%
			ungroup()
	}

	if(affix_percent){
		if(tableone %>% select(one_of('Level')) %>% ncol() != 0){
			tableone_out <- tableone_out %>%
				rowwise() %>%
				mutate(
					across(
						one_of(columns),
						~case_when(
							Variable %in% c('n', 'n (%)') | Variable %in% override_rows ~ .x %>% str_replace('\\)', '%)'),
							Level != '' ~ .x %>% str_replace('\\)', '%)'),
							.default = .x
						)
					)
				) %>%
				ungroup()
		} else {
			tableone_out <- tableone_out %>%
				rowwise() %>%
				mutate(
					across(
						one_of(columns),
						~case_when(
							Variable %in% c('n', 'n (%)') | Variable %in% override_rows ~ .x %>% str_replace('\\)', '%)'),
							.default = .x
						)
					)
				) %>%
				ungroup()
		}
	}

	return(tableone_out)
}

print_kable_one <- function(data, comma = TRUE, bold = TRUE, underline = TRUE, n_percent_row = TRUE, strip_nonpara_trailing = TRUE, adorn_footnotes = FALSE, p_accuracy = 0.001, bold_p = TRUE, override_rows = NULL, ...){
	output <- data %>%
		as_tibble(rownames = 'Variable') %>%
		select(-one_of('test')) %>%
		rowwise() %>%
		mutate(
			across(
				one_of('p'),
				~case_when(
					.x %>% str_detect('<') ~ .x,
					.x %>% str_detect('>') ~ .x,
					TRUE ~ .x %>% as.numeric() %>% scales::pvalue(accuracy = p_accuracy)
				)
			)
		) %>%
		ungroup() %>%
		rename(
			any_of(
				c(
					Level = 'level',
					Total = 'Overall',
					`p-value` = 'p'
				)
			)
		)

	if(ncol(output) != 2 & n_percent_row){
		n_row <- output %>%
			filter(Variable == 'n') %>%
			mutate(
				across(
					!one_of('Variable', 'Level', 'p-value'),
					~(.x %>% str_replace_all('[^0-9]', '') %>% as.numeric)
				),
			)

		n_percent <- n_row %>%
			mutate(
				Variable = 'n (%)',
				Total = Total %>% as.character(),
				across(
					!one_of('Variable', 'Level', 'Total', 'p-value'),
					~(
						paste0(.x %>% as.numeric(), ' (', scales::percent(
							(.x %>% as.numeric)/(n_row %>% pull(Total) %>% as.numeric),
							accuracy = 0.1, suffix = ''), ')')
					)
				)
			)
	}

	if(n_percent_row & output %>% ncol() != 3){
		output <- bind_rows(
			n_percent,
			output %>%
				filter(Variable != 'n')
		)
	}

	if(comma){
		output <- output %>%
			tableone_style(strip_nonpara_trailing = strip_nonpara_trailing, override_rows = override_rows, ...)
	}

	output_print <- output %>%
		print_kable(bold_p = bold_p, ...)

	if(bold){
		output_print <- output_print %>%
			tab_style(
				style = cell_text(weight = 'bold'),
				locations = cells_body(columns = Variable)
			)
	}

	if(underline & output %>% select(one_of('Level')) %>% ncol() != 0){
		output_print <- output_print %>%
			tab_style(
				style = cell_text(decorate = 'underline'),
				locations = cells_body(columns = Level)
			)
	}

	if(adorn_footnotes){
		output_print <- output_print %>%
			tab_footnote(
				footnote = gt::html('<em>Dichotomous and categorical variables are presented as count (%). Normally distributed continuous variables are presented as mean (standard deviation), while non-normally distributed continuous variables are displayed as median [IQR].</em>')
			) %>%
			tab_footnote(
				footnote = gt::html('<em><strong>Bolded</strong> entries in the p-value column indicate statistical significance at p < 0.05.</em>')
			)
	}

	# output_print <- output_print %>%
	# 	fmt_markdown(
	# 		columns = one_of('Variable', 'Level')
	# 	) %>%
	# 	cols_label_with(
	# 		fn = md
	# 	)

	return(output_print)
}

print_kable_fit <- function(data, dash_substitution = '–', add_space = TRUE, comma_percent_columns = NULL, remove_levels_cont = TRUE, remove_columns = NULL, ...){
	output <- data %>%
		as_tibble() %>%
		rename(
			any_of(
				c(
					`n (%)` = 'Total',
					`n (%)` = 'all',
					Variable = 'label',
					Level = 'levels'
				)
			)
		) %>%
		mutate(
			Level = case_when(
				str_detect(`n (%)`, '100.0') ~ paste0('Range: ', str_replace(Level, ',', ', ')),
				TRUE ~ Level
			),
			`n (%)` = `n (%)` %>% str_replace_all(' \\(100.0\\)', ''),
			across(
				everything(),
				~case_when(
					.x == '-' ~ 'Reference',
					.default = .x
				)
			),
			across(
				everything(),
				~(
					.x %>%
						str_replace_all('=', ' = ') %>%
						str_replace_all('<', ' < ') %>%
						str_replace_all('>', ' > ')
				)
			)
		) %>%
		select(-one_of('unit', 'value')) %>%
		dplyr::arrange()

	comma_percent_columns <- c(
		output %>%
			select(Level:`n (%)`) %>%
			names() %>%
			setdiff(., 'Level'),
		comma_percent_columns
	)

	output <- output %>%
		rowwise() %>%
		mutate(
			across(
				one_of(comma_percent_columns),
				~case_when(
					str_detect(Level, 'Range') | Level %in% c('Mean (SD)', 'Median (IQR)') ~ adorn_commas(.x, round_digits = 0),
					.default = adorn_commas(.x, no_round_n = TRUE)
				)
			)
		) %>%
		ungroup() %>%
		mutate(
			across(
				one_of(comma_percent_columns),
				~str_replace(.x, '\\)', '%\\)')
			),
			across(
				!one_of('Variable', 'Level', comma_percent_columns),
				~case_when(
					str_detect(.x, 'to') | !add_space ~ .x %>%
						str_replace_all('-', dash_substitution),
					.default = .x %>%
						str_replace_all('-', paste0(' ', dash_substitution, ' '))
				)
			)
		)

	if(remove_levels_cont){
		output <- output %>%
			mutate(
				across(
					one_of('Level', comma_percent_columns),
					~case_when(
						str_detect(Level, 'Range') | Level %in% c('Mean (SD)', 'Median (IQR)') ~ '',
						.default = .x
					)
				)
			)
	}

	output <- output %>%
		select(-one_of(remove_columns)) %>%
		print_kable(underline = TRUE, underline_column = 2) %>%
		tab_style(
			style = cell_text(weight = 'bold'),
			locations = cells_body(columns = 1)
		)

	return(output)
}

print_skim_kable <- function(data){
	if(!'skim_list' %in% class(data)){
		data <- data %>%
			skimr::partition()
	}

	purrr::walk2(
		data,
		data %>% names(),
		~(
			.x %>%
				# mutate_at(vars(one_of('n_missing', 'n_unique')), ~scales::comma(., accuracy = 1)) %>%
				# mutate_at(vars(one_of('complete_rate')), ~scales::comma(., accuracy = .001)) %>%
				# mutate_if(is.numeric, ~scales::comma(., accuracy = 0.01)) %>%
				print_kable() %>%
				fmt_number(
					columns = -one_of('n_missing', 'complete_rate', 'empty', 'n_unique', 'whitespace'),
					sep = ','
				) %>%
				fmt_number(
					columns = 'complete_rate',
					decimals = 3
				) %>%
				tab_caption(caption = paste0('<b>Skim Type</b>: <u>', .y, '</u>') %>% gt::html()) %>%
				tab_style(
					style = cell_text(decorate = 'underline'),
					locations = cells_body(columns = 1)
				) %>%
				print()
		)
	)
}

print_kable_gtsummary_uni <- function(model, round_digits = 2, p_accuracy = 0.001, dash_substitution = '–', use_abbreviated_measure = FALSE, exponentiate_override = NULL, ci_delim = ' to ', iqr_sep = ' – ', measure_print_override = NULL, ci_print = '95% CI', p_print = 'p-value', ref_print = 'Reference', type_spec = NULL, ...){
	reset_gtsummary_theme()

	theme_gtsummary_language(
		language = 'en',
		iqr.sep = iqr_sep,
		ci.sep = ci_delim,
		set_theme = TRUE
	)

	theme_gtsummary_printer(
		print_engine = 'tibble',
		set_theme = TRUE
	)

	type_options <- list(
		all_dichotomous() ~ 'categorical'
	)

	if(!rlang::is_empty(type_spec)){
		type_options <- c(
			type_options,
			type_spec
		)
	}

	summary_table <- model %>%
		get_data() %>%
		tbl_summary(
			include = model %>% find_predictors() %>% pluck(1),
			statistic = list(
				all_continuous() ~ "{N_obs}",
				all_categorical() ~ "{n} ({p}%)"
			),
			digits = all_categorical() ~ c(0, 1),
			missing = 'ifany',
			type = type_options,
			...
		) %>%
		as_tibble() %>%
		rename(
			'n (%)' = 2
		) %>%
		select(-one_of('**Characteristic**'))

	uv_y <<- model %>% find_response()

	if(inherits(model, 'coxph')){
		measure <- 'Hazard Ratio'
		abbreviated_measure <- 'HR'
		exponentiate = TRUE
		uv_y <<- model %>% find_formula() %>% pluck(1) %>% pluck(2)
	} else if((inherits(model, 'glm') && model$family$link == 'logit') |
						(inherits(model, 'glmerMod') & (model %>% get_family())$family == 'binomial')){
		measure <- 'Odds Ratio'
		abbreviated_measure <- 'OR'
		exponentiate = TRUE
	} else if(inherits(model, 'lm') | inherits(model, 'lmerMod')){
		measure <- 'β Coefficient'
		abbreviated_measure <- 'β'
		exponentiate = FALSE
	} else {
		measure <- 'Estimate'
		abbreviated_measure <- 'Estimate'
	}

	if(!rlang::is_empty(exponentiate_override)){
		exponentiate <- exponentiate_override
	}

	if(use_abbreviated_measure){
		measure_print <- abbreviated_measure
	} else {
		measure_print <- measure
	}

	if(!rlang::is_empty(measure_print_override)){
		measure_print <- measure_print_override
	}

	formula <- '{y} ~ {x}'

	if(inherits(model, 'lmerMod') | inherits(model, 'glmerMod')){
		random_effects <- model %>%
			find_random() %>%
			pluck(1)

		random_effects_formula <- random_effects %>%
			paste0('(1|', ., ')', collapse = ' + ')

		formula <- paste0(formula, ' + ', random_effects_formula)
	}

	model <<- model

	if(inherits(model, 'glm') | inherits(model, 'glmerMod')){
		uni_table <- tbl_uvregression(
			data = model %>% get_data(),
			y = uv_y %>% eval(),
			include = model %>% find_predictors() %>% pluck(1),
			method = (model %>% get_call() %>% as.character())[1] %>% get(),
			method.args = list(
				family = (model %>% get_family())$family,
				weights = model %>% insight::get_weights()
			),
			formula = formula,
			exponentiate = exponentiate,
			estimate_fun = ~sprintf(paste0('%.0', round_digits, 'f'), .x),
			pvalue_fun = ~scales::pvalue(.x, accuracy = p_accuracy),
			add_estimate_to_reference_rows = TRUE
		)
	} else {
		uni_table <- tbl_uvregression(
			data = model %>% get_data(),
			y = uv_y %>% eval(),
			include = model %>% find_predictors() %>% pluck(1),
			method = (model %>% get_call() %>% as.character())[1] %>% get(),
			method.args = list(
				weights = model %>% insight::get_weights()
			),
			formula = formula,
			exponentiate = exponentiate,
			estimate_fun = ~sprintf(paste0('%.0', round_digits, 'f'), .x),
			pvalue_fun = ~scales::pvalue(.x, accuracy = p_accuracy),
			add_estimate_to_reference_rows = TRUE
		)
	}

	rm(uv_y, envir = globalenv())

	uni_table <- uni_table %>%
		modify_header(
			label = 'level',
			stat_n = 'N',
			estimate = 'estimate',
			ci = 'ci',
			p.value = 'p-value'
		) %>%
		as_tibble() %>%
		select(-one_of('N', '**95% CI**')) %>%
		rename_all(
			~paste0('uni_', .x)
		)

	output <-
		bind_cols(
			c(model %>% get_data() %>% select(model %>% find_predictors() %>% pluck(1)) %>% var_label() %>% pluck(1), rep('', uni_table %>% nrow()-1)),
			uni_table
		) %>%
		rename(
			Variable = 1,
			Level = uni_level
		) %>%
		mutate(
			Level = case_when(
				Level == model %>% get_data() %>% select(model %>% find_predictors() %>% pluck(1)) %>% var_label() %>% pluck(1) ~ '',
				.default = Level
			)
		)

	output <- output %>%
		replace_with_na_all(condition = ~.x %in% c('NA')) %>%
		mutate(
			across(
				ends_with('_ci'),
				~case_when(
					!is.na(.x) & .x != '—' ~ paste0('(', .x, ')')
				)
			),
			across(
				everything(),
				~str_replace_all(.x, '-', dash_substitution)
			)
		) %>%
		rowwise() %>%
		mutate(
			uni_estimate = case_when(
				uni_estimate == sprintf(paste0('%.0', round_digits, 'f'), 0) & is.na(uni_ci) & is.na(`uni_p-value`) ~ ref_print,
				uni_estimate == sprintf(paste0('%.0', round_digits, 'f'), 1) & is.na(uni_ci) & is.na(`uni_p-value`) ~ ref_print,
				.default = uni_estimate
			),
			across(
				one_of('uni_p-value'),
				~case_when(
					uni_estimate == ref_print & is.na(uni_ci) & is.na(`uni_p-value`) ~ '—',
					.default = .x
				)
			)
		) %>%
		ungroup() %>%
		print_kable() %>%
		tab_style(
			style = cell_text(weight = 'bold'),
			locations = cells_body(columns = 1)
		) %>%
		tab_style(
			style = cell_text(decorate = 'underline'),
			locations = cells_body(columns = 2)
		) %>%
		cols_label(
			uni_estimate = abbreviated_measure,
			uni_ci = ci_print,
			`uni_p-value` = p_print
		) %>%
		tab_spanner(
			label = gt::html('<strong><u>Univariable</u></strong>'),
			columns = c(uni_estimate, uni_ci, `uni_p-value`)
		) %>%
		tab_style(
			style = cell_text(weight = 'bold'),
			locations = cells_body(
				columns = `uni_p-value`,
				rows = `uni_p-value` %>% str_remove('>') %>% str_remove('<') %>% as.numeric() < 0.05
			)
		) %>%
		cols_merge(
			columns = c(uni_estimate, uni_ci)
		) %>%
		cols_label(
			uni_estimate = paste0(measure_print, ' (', ci_print, ')')
		) %>%
		cols_label_with(
			fn = ~paste0('<strong>', .x, '</strong>') %>% gt::html()
		) %>%
		tab_style(
			style = cell_text(style = 'italic'),
			locations = cells_body(
				columns = one_of('uni_estimate'),
				rows = (uni_estimate == ref_print)
			)
		)

	return(output)
}

print_kable_gtsummary <- function(model, round_digits = 2, p_accuracy = 0.001, dash_substitution = '–', use_abbreviated_measure = FALSE, exponentiate_override = NULL, ci_delim = ' to ', iqr_sep = ' – ', measure_print_override = NULL, ci_print = '95% CI', p_print = 'p-value', ref_print = 'Reference', type_spec = NULL, hide_n_percent_col = FALSE, add_events_n = TRUE, hide_events_n_percent_col = FALSE, ...){
	reset_gtsummary_theme()

	theme_gtsummary_language(
		language = 'en',
		iqr.sep = iqr_sep,
		ci.sep = ci_delim,
		set_theme = TRUE
	)

	theme_gtsummary_printer(
		print_engine = 'tibble',
		set_theme = TRUE
	)

	type_options <- list(
		all_dichotomous() ~ 'categorical'
	)

	if(!rlang::is_empty(type_spec)){
		type_options <- c(
			type_options,
			type_spec
		)
	}

	continuous_var_data <- model %>%
		get_predictors() %>%
		select_if(is.numeric) %>%
		names() %>%
		as_tibble() %>%
		rowwise() %>%
		mutate(
			label = model %>% get_predictors() %>% pull(value) %>% var_label(),
			continuous_n = model %>% get_predictors() %>% pull(value) %>% na.omit() %>% length() %>% scales::number(big.mark = ',',) %>% as.character()
		)

	summary_table <- model %>%
		get_data() %>%
		tbl_summary(
			include = model %>% find_predictors() %>% pluck(1),
			statistic = list(
				all_continuous() ~ "{mean}",
				all_categorical() ~ "{n} ({p}%)"
			),
			digits = all_categorical() ~ c(0, 1),
			missing = 'ifany',
			type = type_options,
			...
		) %>%
		as_tibble() %>%
		rename(
			'n (%)' = 2
		) %>%
		left_join(
			continuous_var_data %>%
				select(label, continuous_n),
			by = c('**Characteristic**' = 'label')
		) %>%
		mutate(
			`n (%)` = case_when(
				!is.na(continuous_n) ~ continuous_n,
				.default = `n (%)`
			)
		) %>%
		select(-one_of('**Characteristic**', 'continuous_n'))

	uv_y <<- model %>% find_response()

	if(inherits(model, 'coxph')){
		measure <- 'Hazard Ratio'
		abbreviated_measure <- 'HR'
		exponentiate = TRUE
		uv_y <<- model %>% find_formula() %>% pluck(1) %>% pluck(2)
	} else if((inherits(model, 'glm') && model$family$link == 'logit') |
						(inherits(model, 'glmerMod') & (model %>% get_family())$family == 'binomial')){
		measure <- 'Odds Ratio'
		abbreviated_measure <- 'OR'
		exponentiate = TRUE
	} else if(inherits(model, 'lm') | inherits(model, 'lmerMod')){
		measure <- 'β Coefficient'
		abbreviated_measure <- 'β'
		exponentiate = FALSE
	} else {
		measure <- 'Estimate'
		abbreviated_measure <- 'Estimate'
	}

	if(!rlang::is_empty(exponentiate_override)){
		exponentiate <- exponentiate_override
	}

	if(use_abbreviated_measure){
		measure_print <- abbreviated_measure
	} else {
		measure_print <- measure
	}

	if(!rlang::is_empty(measure_print_override)){
		measure_print <- measure_print_override
	}

	formula <- '{y} ~ {x}'

	if(inherits(model, 'lmerMod') | inherits(model, 'glmerMod')){
		random_effects <- model %>%
			find_random() %>%
			pluck(1)

		random_effects_formula <- random_effects %>%
			paste0('(1|', ., ')', collapse = ' + ')

		formula <- paste0(formula, ' + ', random_effects_formula)
	}

	model <<- model

	if(inherits(model, 'glm') | inherits(model, 'glmerMod')){
		uni_table <- tbl_uvregression(
			data = model %>% get_data(),
			y = uv_y %>% eval(),
			include = model %>% find_predictors() %>% pluck(1),
			method = (model %>% get_call() %>% as.character())[1] %>% get(),
			method.args = list(
				family = (model %>% get_family())$family,
				weights = model %>% insight::get_weights()
			),
			formula = formula,
			exponentiate = exponentiate,
			estimate_fun = ~sprintf(paste0('%.0', round_digits, 'f'), .x),
			pvalue_fun = ~scales::pvalue(.x, accuracy = p_accuracy),
			add_estimate_to_reference_rows = TRUE
		)
	} else {
		uni_table <- tbl_uvregression(
			data = model %>% get_data(),
			y = uv_y %>% eval(),
			include = model %>% find_predictors() %>% pluck(1),
			method = (model %>% get_call() %>% as.character())[1] %>% get(),
			method.args = list(
				weights = model %>% insight::get_weights()
			),
			formula = formula,
			exponentiate = exponentiate,
			estimate_fun = ~sprintf(paste0('%.0', round_digits, 'f'), .x),
			pvalue_fun = ~scales::pvalue(.x, accuracy = p_accuracy),
			add_estimate_to_reference_rows = TRUE
		)
	}

	rm(uv_y, envir = globalenv())

	uni_table <- uni_table %>%
		modify_header(
			label = 'variable',
			stat_n = 'N',
			estimate = 'estimate',
			conf.low = 'ci',
			p.value = 'p-value'
		) %>%
		as_tibble() %>%
		select(-one_of('N', 'variable')) %>%
		rename_all(
			~paste0('uni_', .x)
		)

	if(uni_table %>% as_tibble() %>% select(matches('p-value')) %>% ncol() == 0){
		uni_table <- uni_table %>%
			left_join(
				.,
				imap(
					model %>% get_predictors(),
					~(
						lmer(
							paste0((model %>% find_response()), ' ~ ', .y, ' + ', random_effects_formula) %>% formula(),
							data = model %>% get_data()
						) %>%
							tidy(conf.int = TRUE) %>%
							mutate_if(is.numeric, ~sprintf(paste0('%0.', round_digits, 'f'), .x)) %>%
							filter(term != '(Intercept)' & effect == 'fixed') %>%
							mutate(
								estimate = estimate %>% as.character(),
								conf.int = paste0(conf.low, ci_delim, conf.high)
							) %>%
							select(term, estimate, conf.int)
					)
				) %>%
					reduce(bind_rows) %>%
					left_join(
						.,
						imap(
							model %>% get_predictors(),
							~(
								lmer(
									paste0((model %>% find_response()), ' ~ ', .y, ' + ', random_effects_formula) %>% formula(),
									data = model %>% get_data()
								) %>%
									broom.helpers::tidy_parameters(effects = 'fixed') %>%
									filter(term != '(Intercept)') %>%
									as_tibble()
							)
						) %>%
							reduce(bind_rows) %>%
							select(term, p.value),
						by = c('term' = 'term')
					) %>%
					select(-term),
				by = c(
					'uni_estimate' = 'estimate',
					'uni_ci' = 'conf.int'
				)
			) %>%
			mutate(p.value = p.value %>% scales::pvalue(accuracy = p_accuracy)) %>%
			rename(`uni_p-value` = p.value)
	}

	multi_table <- model %>%
		tbl_regression(
			exponentiate = exponentiate,
			estimate_fun = ~sprintf(paste0('%.0', round_digits, 'f'), .x),
			pvalue_fun = ~scales::pvalue(.x, accuracy = p_accuracy),
			add_estimate_to_reference_rows = TRUE
		)

	if(add_events_n & (
		inherits(model, 'coxph') |
		(inherits(model, 'glm') && model$family$link == 'logit') |
		(inherits(model, 'glmerMod') && (model %>% get_family())$family == 'binomial')
	)){
		multi_table <- multi_table %>%
			add_n(location = 'level') %>%
			add_nevent(location = 'level') %>%
			modify_table_body(
				~ .x %>%
					dplyr::mutate(
						stat_nevent_rate =
							ifelse(
								!is.na(stat_nevent),
								paste0(style_sigfig(stat_nevent / stat_n, scale = 100, digits = 3), "%"),
								NA
							),
						.after = stat_nevent
					)
			) %>%
			# merge the colums into a single column
			modify_column_merge(
				pattern = "{stat_nevent} ({stat_nevent_rate})",
				rows = !is.na(stat_nevent)
			)
	}

	multi_table <- multi_table %>%
		bold_levels() %>%
		modify_header(
			label = 'variable',
			stat_n = 'N',
			stat_nevent = 'n_event',
			estimate = 'estimate',
			conf.low = 'ci',
			p.value = 'p-value'
		) %>%
		as_tibble() %>%
		select(-one_of('N')) %>%
		rename_all(
			~paste0('multi_', .x)
		) %>%
		separate_wider_delim(
			cols = multi_variable,
			delim = '__',
			names = c('Variable', 'Level'),
			too_few = 'align_start',
			too_many = 'merge'
		) %>%
		mutate(
			Level = Level %>% str_remove('__')
		)

	if(multi_table %>% as_tibble() %>% select(matches('p-value')) %>% ncol() == 0){
		multi_table <- multi_table %>%
			left_join(
				.,
				model %>%
					tidy(conf.int = TRUE) %>%
					mutate_if(is.numeric, ~sprintf(paste0('%0.', round_digits, 'f'), .x)) %>%
					filter(term != '(Intercept)' & effect == 'fixed') %>%
					mutate(
						estimate = estimate %>% as.character(),
						conf.int = paste0(conf.low, ci_delim, conf.high)
					) %>%
					select(term, estimate, conf.int) %>%
					left_join(
						.,
						model %>%
							model_parameters(effects = 'fixed') %>%
							standardize_names(style = 'broom') %>%
							as_tibble() %>%
							select(term, p.value),
						by = c('term' = 'term')
					) %>%
					select(-term),
				by = c(
					'multi_estimate' = 'estimate',
					'multi_ci' = 'conf.int'
				)
			) %>%
			mutate(p.value = p.value %>% scales::pvalue(accuracy = p_accuracy)) %>%
			rename(`multi_p-value` = p.value)
	}

	output <- bind_cols(
		summary_table,
		uni_table,
		multi_table
	) %>%
		relocate(Variable, Level, `n (%)`) %>%
		relocate(
			any_of(
				'multi_n_event'
			)
		) %>%
		rename(
			any_of(
				c(
					`Events (%)` = 'multi_n_event'
				)
			)
		) %>%
		relocate(one_of('Events (%)'), .after = 'n (%)')

	output <- output %>%
		replace_with_na_all(condition = ~.x %in% c('NA')) %>%
		mutate(
			across(
				ends_with('_ci'),
				~case_when(
					!is.na(.x) ~ paste0('(', .x, ')')
				)
			),
			across(
				everything(),
				~str_replace_all(.x, '-', dash_substitution)
			)
		) %>%
		rowwise() %>%
		mutate(
			uni_estimate = case_when(
				uni_estimate == '1.00' & is.na(uni_ci) & is.na(`uni_p-value`) ~ ref_print,
				.default = uni_estimate
			),
			uni_ci = case_when(
				uni_estimate == '1.00' & is.na(uni_ci) & is.na(`uni_p-value`) ~ NA_character_,
				.default = uni_ci
			),
			across(
				one_of('uni_p-value'),
				~case_when(
					uni_estimate == ref_print & is.na(uni_ci) & is.na(`uni_p-value`) ~ '—',
					.default = .x
				)
			),
			multi_estimate = case_when(
				multi_estimate == '1.00' & is.na(multi_ci) & is.na(`multi_p-value`) ~ ref_print,
				.default = multi_estimate
			),
			multi_ci = case_when(
				multi_estimate == '1.00' & is.na(multi_ci) & is.na(`multi_p-value`) ~ NA_character_,
				.default = multi_ci
			),
			across(
				one_of('multi_p-value'),
				~case_when(
					multi_estimate == ref_print & is.na(multi_ci) & is.na(`multi_p-value`) ~ '—',
					.default = .x
				)
			)
		) %>%
		ungroup() %>%
		print_kable() %>%
		tab_style(
			style = cell_text(weight = 'bold'),
			locations = cells_body(columns = 1)
		) %>%
		tab_style(
			style = cell_text(decorate = 'underline'),
			locations = cells_body(columns = 2)
		) %>%
		cols_label(
			uni_estimate = abbreviated_measure,
			uni_ci = ci_print,
			`uni_p-value` = p_print,
			multi_estimate = abbreviated_measure,
			multi_ci = ci_print,
			`multi_p-value` = p_print
		) %>%
		tab_spanner(
			label = gt::html('<strong><u>Univariable</u></strong>'),
			columns = c(uni_estimate, uni_ci, `uni_p-value`)
		) %>%
		tab_spanner(
			label = gt::html('<strong><u>Multivariable</u></strong>'),
			columns = c(multi_estimate, multi_ci, `multi_p-value`)
		) %>%
		tab_style(
			style = cell_text(weight = 'bold'),
			locations = cells_body(
				columns = `uni_p-value`,
				rows = `uni_p-value` %>% str_remove('>') %>% str_remove('<') %>% as.numeric() < 0.05
			)
		) %>%
		tab_style(
			style = cell_text(weight = 'bold'),
			locations = cells_body(
				columns = `multi_p-value`,
				rows = `multi_p-value` %>% str_remove('>') %>% str_remove('<') %>% as.numeric() < 0.05
			)
		) %>%
		cols_merge(
			columns = c(uni_estimate, uni_ci)
		) %>%
		cols_merge(
			columns = c(multi_estimate, multi_ci)
		) %>%
		cols_label(
			uni_estimate = paste0(measure_print, ' (', ci_print, ')'),
			multi_estimate = paste0(measure_print, ' (', ci_print, ')')
		) %>%
		cols_label_with(
			fn = ~paste0('<strong>', .x, '</strong>') %>% gt::html()
		) %>%
		tab_style(
			style = cell_text(style = 'italic'),
			locations = cells_body(
				columns = one_of('uni_estimate', 'multi_estimate'),
				rows = (uni_estimate == ref_print | multi_estimate == ref_print)
			)
		)

	if(hide_n_percent_col){
		output <- output %>%
			cols_hide(
				columns = 'n (%)'
			)
	}

	if(hide_events_n_percent_col){
		output <- output %>%
			cols_hide(
				columns = 'Events (%)'
			)
	}

	return(output)
}
