jgn_print_dsa <- function(dsa, print = TRUE, force_split = FALSE, override = NA, ...){
  output <- map_dfr(
    .x = dsa$mean.cv.risk.DSA,
    .f = function(.x){
      id <- which(dsa$mean.cv.risk.DSA == .x)
      tibble(
        `# partitions` = id,
        `mean CV error` = dsa$mean.cv.risk.DSA[id],
        `sd CV error` = dsa$sd.cv.risk[id],
        `test risk` = dsa$test.set.risk.DSA[id]
      )
    }
  )


  if(rlang::is_na(override)){
	  best_split <<- output %>%
	    filter(if(force_split) `# partitions` != 1 else TRUE) %>%
	  	filter(`mean CV error` == min(`mean CV error`, na.rm = TRUE)) %>%
	    pull(`# partitions`)
  } else {
  	best_split <<- override
  }

  if(print){
    output %>%
      rename(
        `Number of Partitions` = `# partitions`,
        `Mean Cross-Validated Error` = `mean CV error`,
        `Standard Deviation Cross-Validated Error` = `sd CV error`,
        `Test Risk` = `test risk`
      ) %>%
  		print_kable(...) %>%
  		tab_style(
  			style = list(
  				cell_text(weight = 'bold'),
  				cell_text(decorate = 'underline')
  			),
  			locations = cells_body(
  				columns = everything(),
  				rows = best_split
  			)
  		) %>%
  		fmt_number(
  			columns = -one_of('Number of Partitions'),
  			sep_mark = ','
  		)
  } else {
    return(output)
  }
}

jgn_print_dsa_importance <- function(dsa, data, print = TRUE, ...){
  output <- dsa$var.importance %>%
    as_tibble(rownames = 'var') %>%
    rowwise() %>%
    mutate(
      Variable = var %>%
        str_remove('(.*)\\$'),
      Label = data %>%
        pull(Variable) %>%
        var_label(),
    ) %>%
    replace_with_na_all(~.x %in% c(0)) %>%
    ungroup() %>%
    reduce(
      .x = list(
        c('Variable', 'var'),
        c('Label', 'Variable')
      ),
      .f = ~relocate(.x, .y[1], .after = .y[2]),
      .init = .
    ) %>%
    select(-var) %>%
    filter(
      if_any(
        starts_with('COG'),
        ~!is.na(.)
      )
    )

  if(print){
    output %>%
      rename_all(
        ~str_replace(.x, 'COG=', 'Terminal Partitions = ')
      ) %>%
  		print_kable(underline = TRUE, underline_column = 2, ...)
  } else {
    return(output)
  }
}

jgn_print_dsa_basis_functions <- function(dsa, partition_set = best_split, colon = TRUE){
	M <- length(dsa$IkPn)
	m <- 2

	if(!rlang::is_empty(partition_set)){
		M <- partition_set
		m <- M
	}

	for(i in m:M){
		cat(sprintf('Best %d partitions\n', i))

		BFs <- dsa$IkPn[[i]]

		for(j in seq(along = BFs)){

			print_string <- '  Partition %d [of %d]:\n'

			if(!colon){
				print_string <- print_string %>%
					str_remove('\\:')
			}

			cat(sprintf(print_string, j, i))

			BF <- BFs[[j]]

			for(K in seq(along = BF[[1]])){
				and <- 0

				for(P in seq(along = BF)){
					range <- BF[[P]][[K]]

					if(any(is.finite(range))){
						var.levels <- dsa$var.levels[[P]]

						if(!is.null(var.levels)){
							var.vals <- seq(along = var.levels)
							var.results <- var.levels[which(range[1] < var.vals &
																								var.vals <= range[2])]
							lower <- ''
							upper <- if(length(var.results) > 1){
								sprintf(' is in {%s}', paste(var.results, collapse = ', '))
							} else {
								sprintf(' == \'%s\'', var.results)
							}

						} else {
							lower <- if(is.finite(range[1])){
								sprintf('%g < ', range[1])
							} else {
								''
							}

							upper <- if(is.finite(range[2])){
								sprintf(' <= %g', range[2])
							} else {
								''
							}
						}

						if(and > 0){
							cat(' & ')
						} else {
							cat('    ')
						}

						variable_print <- dsa$var.names[P]

						if(variable_print %>% str_detect('\\$')){
							variable_print <- variable_print %>%
								str_extract('\\$(.*)$', group = TRUE)
						}

						if(!sjmisc::is_empty(lower) & !sjmisc::is_empty(upper)){
							cat(sprintf('(%s%s & %s%s)', lower, variable_print, variable_print, upper))
						} else {
							cat(sprintf('(%s%s%s)', lower, variable_print, upper))
						}

						and <- and + 1
					}
				}
				cat('\n')
			}
		}
	}
}

jgn_print_dsa_basis_functions_kable <- function(dsa, partition_set = best_split, colon = FALSE, remove_parens = TRUE, ...){
  output <- dsa %>%
    jgn_print_dsa_basis_functions(partition_set = partition_set, colon = colon, ...) %>%
    capture.output() %>%
    as_tibble() %>%
    rename(
      Split = 1
    )

  if(remove_parens){
  	output <- output %>%
  		mutate(
  			Split = Split %>% str_remove_all('\\(') %>% str_remove_all('\\)')
  		)
  }

  output %>%
  	print_kable(format_escape = FALSE, ...) %>%
  	tab_style(
  		style = cell_text(weight = 'bold'),
  		locations = cells_body(
  			columns = Split,
  			rows = Split %>% str_detect('Best')
  		)
  	) %>%
  	tab_style(
  		style = cell_text(decorate = 'underline'),
  		locations = cells_body(
  			columns = Split,
  			rows = Split %>% str_detect('Partition')
  		)
  	)
}

jgn_print_dsa_coefficients <- function(dsa){
  cat('Outcome:\n')
  for(i in seq(along = dsa$coefficients)){
    coef <- dsa$coefficients[[i]]
    if(dsa$options$outcome.class == 'numeric' || dsa$options$outcome.class == 'survival'){
      n <- length(coef)
      ncoef <- if(n > 1){
        coef[2:n] + coef[1]
      } else{
        coef
      }
      names(ncoef) <- c(rep('', n-1))    # remove names of variables - remainder from regression
      cat(sprintf('Best of %d partitions:\n', i))
      for(j in 1:(n-1)){
        cat(sprintf('   Part.%d ',j))
      }
      cat('\n')
      for(j in 1:(n-1)){
        cat('   ', round(ncoef[j], 3))
      }
      cat('\n')
    } else if(dsa$options$outcome.class == 'factor'){
      ncoef <- factor(dsa$y.levels[coef], levels = dsa$y.levels)
      print(ncoef)
    } else {
      cat(sprintf('[unsupported outcome class: %s]\n', dsa$options$outcome.class))
    }
  }
  cat('\n')
}

jgn_print_dsa_coefficients_kable <- function(dsa, print = TRUE, partition_set = best_split){
  output <- dsa %>%
    jgn_print_dsa_coefficients() %>%
    capture.output() %>%
    as_tibble() %>%
    mutate_all(~str_squish(.x)) %>%
    filter(
      !str_detect(value, 'Outcome') &
        !str_detect(value, 'Best') &
        !str_detect(value, 'Part') &
        value != ''
    ) %>%
    rename(
      Partition = value
    ) %>%
    separate_wider_delim(delim = ' ', cols = Partition, names_sep = ' ', too_few = 'align_start') %>%
    type_convert()

  if(print){
    output <- output %>%
      print_kable() %>%
    	fmt_number(sep_mark = ',') %>%
    	tab_style(
    		style = cell_text(weight = 'bold'),
    		locations = cells_body(
    			rows = partition_set
    		)
    	)

    if(dsa$options$loss.fx == 'Brier'){
      output <- output %>%
      	opt_footnote_marks(marks = 'extended') %>%
      	tab_footnote(
      		footnote = paste0('<em>As Brier scoring has been used as the loss function, the predicted outcome is a probability, i.e. between 0 and 1, of not having had the event by t*. Thus, the coefficients represent the likelihood of remaining event-free by the median time-to-event for the overall dataset (', dsa$options$brier.vec,' days) for each partition.</em>') %>% gt::html()
      	)
    }

    if(dsa$options$loss.fx == 'IPCW'){
      output <- output %>%
      	opt_footnote_marks(marks = 'extended') %>%
      	tab_footnote(
      		footnote = gt::html('<em>Since the inverse-probability-of-censoring weighting (IPCW) was used as the loss function, the coefficients represent the predicted survival time for each partition.</em>')
      	)
    }

    return(output)
  } else {
    return(output)
  }
}
