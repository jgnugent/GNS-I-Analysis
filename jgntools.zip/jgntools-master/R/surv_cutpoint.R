jgn_dichotomize <- function(x, cutpoint, labels = c('low', 'high'), cutpoint_round_digits = NULL){
	if(!rlang::is_empty(cutpoint_round_digits)){
		cutpoint_display <- cutpoint %>% round(digits = cutpoint_round_digits)
	} else {
		cutpoint_display <- cutpoint
	}

	cutpoint_display <- paste0(cutpoint_display, ' ', unit)

	grps <- x
  grps[x <= cutpoint] = paste0(labels[1] %>% str_to_title(), ' (≤', cutpoint_display, ')')
  grps[x > cutpoint] = paste0(labels[2] %>% str_to_title(), ' (>', cutpoint_display, ')')

  grps
}

jgn_surv_cutpoint_plot <- function(x, variables = NULL, ggtheme = theme_jgn(), bins = 30, cutpoint_round_digits = NULL, parse_markdown = FALSE, ...){
  if(!inherits(x, 'surv_cutpoint')){
    stop('x must be an object of class surv_cutpoint.')
  }

  data <- x$data
  surv_data <- x$data[, 1:2]
  data <- x$data[, -1*c(1:2), drop = FALSE]

  if(is.null(variables)){
    variables <- colnames(data)
  }

  data <- data[, variables, drop = FALSE]
  cutpoints <- x$cutpoint[variables, 'cutpoint']
  nvar <- length(variables)

  for(variable in variables){
    max_stat <- x[[variable]]

    p_data <- data.frame(
      stats = max_stat$stats,
      cuts = max_stat$cuts,
      Group = jgn_dichotomize(max_stat$cuts, max_stat$estimate, cutpoint_round_digits = cutpoint_round_digits)
    )

    vline_df <- data.frame(
      x1 = max_stat$estimate,
      x2 = max_stat$estimate,
      y1 = 0,
      y2 = max(p_data$stats)
    )

    cutpoint_label <- paste0('Cutpoint: ', round(max_stat$estimate, 2))

    x1 <- y1 <- x2 <- y2 <- NULL

    max_stat_p <- ggplot(
      data = p_data,
      mapping = aes(cuts, stats)
    ) +
      geom_point(
        aes(color = Group),
        shape = 19
      ) +
      geom_segment(
        aes(
          x = x1,
          y = y1,
          xend = x2,
          yend = y2
        ),
        data = vline_df,
        linetype = 'dashed',
        linewidth = 0.5
      ) +
      ggplot2::annotate(
        'label',
        x = max_stat$estimate,
        y = -0.1,
        label = cutpoint_label,
        size = 4,
        family = font
      ) +
      labs(
        x = x$data %>% pull(variable) %>% var_label(),
        y = 'Standardized Log-Rank Statistic',
        title = 'Maximally Selected Rank Statistics'
      ) +
    	theme_jgn() +
    	scale_color_d3() +
    	scale_fill_d3() +
    	expand_limits(x = -0.1, y = -0.2)

    distribution <- ggpubr::gghistogram(
      p_data,
      x = 'cuts',
      fill = 'Group',
      main = 'Distribution',
      ylab = 'Density',
      xlab = x$data %>% pull(variable) %>% var_label(),
      add_density = TRUE,
      bins = bins
    ) +
    	theme_jgn() +
    	scale_color_d3() +
    	scale_fill_d3()

    if(parse_markdown){
    	distribution <- distribution +
    		theme(
    			axis.title.x = ggtext::element_markdown(),
    			legend.title = ggtext::element_markdown(),
    			legend.text = ggtext::element_markdown()
    		)

    	max_stat_p <- max_stat_p +
    		theme(
    			axis.title.x = ggtext::element_markdown(),
    			legend.title = ggtext::element_markdown(),
    			legend.text = ggtext::element_markdown()
    		)
    }

    cowplot::plot_grid(
    	distribution,
    	max_stat_p,
    	nrow = 2
    ) %>%
    	print()
  }
}
