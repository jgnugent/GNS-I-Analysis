jgn_forest_model_panels <- function(model = NULL, factor_separate_line = TRUE, measure = NULL, trans_char = 'I', sample_size = NULL){
	if(is.list(model) &&
		 inherits(model[[1]], 'rma')){
		model <- model[[1]]
	}
	if(inherits(model, 'rma')){
		if(trans_char == 'I'){
			trans_char <- 'FALSE'
		}
		measure <- measure %||% rma_setlab(
			model$measure,
			transf.char = 'FALSE',
			atransf.char = trans_char,
			gentype = 1
		)
		panels <- list(
			forest_panel(width = 0.03),
			forest_panel(
				width = 0.01,
				display = study,
				fontface = 'bold',
				heading = 'Study',
				width_group = 1
			),
			forest_panel(
				width = 0.18,
				display = stat,
				parse = TRUE,
				width_group = 1
			),
			forest_panel(
				width = 0.05,
				display = n,
				hjust = 1,
				heading = 'N'
			),
			forest_panel(
				width = 0.03,
				item = 'vline',
				hjust = 0.5
			),
			forest_panel(
				width = 0.55,
				item = 'forest',
				hjust = 0.5,
				heading = measure,
				linetype = 'dashed',
				line_x = 0
			),
			forest_panel(
				width = 0.03,
				item = 'vline',
				hjust = 0.5
			),
			forest_panel(
				width = 0.12,
				display = sprintf(
					'%0.2f (%0.2f, %0.2f)',
					trans(estimate),
					trans(conf.low),
					trans(conf.high)
				),
				display_na = NA
			),
			forest_panel(width = 0.03)
		)
	} else {
		if(is.null(measure)){
			if(inherits(model, 'coxph')){
				measure <- 'Hazard Ratio (HR)'
				abbreviated_measure <- 'HR'
			} else if((inherits(model, 'glm') &&
								 model$family$link == 'logit') | (inherits(model, 'glmerMod') & (model %>% get_family())$family == 'binomial')){
				measure <- 'Odds Ratio (OR)'
				abbreviated_measure <- 'OR'
			} else if(inherits(model, 'lm') | (inherits(model, 'lmerMod') & (model %>% get_family())$family == 'gaussian')){
				measure <- 'β Coefficient'
				abbreviated_measure <- 'β'
			} else {
				measure <- 'Estimate'
				abbreviated_measure <- 'Estimate'
			}
		}

		if(inherits(model, 'lmerMod') | inherits(model, 'glmerMod')){
			panels <- list(
				forest_panel(width = 0.03),
				forest_panel(
					width = 0.15,
					display = variable,
					fontface = 'bold',
					heading = 'Variable',
					width_group = 1
				),
				forest_panel(
					width = 0.15,
					display = level,
					width_group = 1
				),
				forest_panel(
					width = 0.03,
					item = 'vline',
					hjust = 0.5
				),
				forest_panel(
					width = 0.55,
					item = 'forest',
					hjust = 0.5,
					heading = measure,
					linetype = 'dashed',
					line_x = 0
				),
				forest_panel(
					width = 0.03,
					item = 'vline',
					hjust = 0.5
				),
				forest_panel(
					width = 0.12,
					display = if_else(
						reference,
						'Reference',
						sprintf(
							'%0.2f (%0.2f, %0.2f)',
							trans(estimate),
							trans(conf.low),
							trans(conf.high)
						)
					),
					display_na = NA,
					heading = paste0('', abbreviated_measure, ' (95% CI)')
				),
				forest_panel(
					width = 0.05,
					display = if_else(reference, '', scales::pvalue(p.value, accuracy = 0.001)),
					display_na = NA,
					hjust = 0,
					heading = 'p-value'
				),
				forest_panel(width = 0.03)
			)
		} else {
			panels <- list(
				forest_panel(width = 0.03),
				forest_panel(
					width = 0.02,
					display = variable,
					fontface = 'bold',
					heading = 'Variable',
					width_group = 1
				),
				forest_panel(
					width = 0.02,
					display = level,
					width_group = 1
				),
				forest_panel(
					width = 0.05,
					display = n,
					hjust = 0,
					heading = 'n'
				),
				forest_panel(width = 0.01),
				forest_panel(
					width = 0.1,
					display = ifelse(
						class == 'factor',
						scales::percent(
							n / sample_size,
							accuracy = 0.1,
							prefix = '(',
							suffix = '%)'
						),
						''
					),
					hjust = 0,
					heading = '(%)'
				),
				forest_panel(
					width = 0.03,
					item = 'vline',
					hjust = 0.5
				),
				forest_panel(
					width = 0.55,
					item = 'forest',
					hjust = 0.5,
					heading = measure,
					linetype = 'dashed',
					line_x = 0
				),
				forest_panel(
					width = 0.03,
					item = 'vline',
					hjust = 0.5
				),
				forest_panel(
					width = 0.12,
					display = if_else(
						reference,
						'Reference',
						sprintf(
							'%0.2f (%0.2f, %0.2f)',
							trans(estimate),
							trans(conf.low),
							trans(conf.high)
						)
					),
					display_na = NA,
					heading = paste0('', abbreviated_measure, ' (95% CI)')
				),
				forest_panel(
					width = 0.05,
					display = if_else(reference, '', scales::pvalue(p.value, accuracy = 0.001)),
					display_na = NA,
					hjust = 0,
					heading = 'p-value'
				),
				forest_panel(width = 0.03)
			)
		}

		if(factor_separate_line){
			panels[[2]][c('width', 'width_group', 'width_fixed')] <-
				list(0.02, 1, TRUE)
			panels[[3]][c('width', 'width_group', 'width_fixed')] <-
				list(0.02, 1, TRUE)
		}
	}
	panels
}

jgn_forest_model <- function(model, panels = jgn_forest_model_panels(model, factor_separate_line = factor_separate_line, sample_size = sample_size_print), covariates = NULL, exponentiate = NULL, funcs = NULL, factor_separate_line = TRUE, format_options = forest_model_format_options(), theme = theme_forest(), limits = NULL, breaks = NULL, return_data = FALSE, recalculate_width = TRUE, recalculate_height = TRUE, model_list = NULL, merge_models = FALSE, exclude_infinite_cis = TRUE, axis_text_size = 14){
	mapping <- aes(estimate, xmin = conf.low, xmax = conf.high)

	if(!is.null(model_list)){
		if(!is.list(model_list)){
			stop('`model_list` must be a list if provided.')
		}
		if(is.null(names(model_list))){
			model_names <- rep('', length(model_list))
		} else {
			model_names <- names(model_list)
		}
		if(any(model_names == '')){
			need_names <- which(model_names == '')
			model_names_needed <-
				vapply(model_list[need_names], function(x)
					quo_name(x$call), character(1))
			model_names[need_names] <- model_names_needed
		}
		if(!merge_models){
			mapping <- c(mapping, aes(section = model_name))
		}
		if(is.null(exponentiate)){
			exponentiate <- inherits(model_list[[1]], 'coxph') ||
				(inherits(model_list[[1]], 'glm') &&
				 	model_list[[1]]$family$link == 'logit') ||
				inherits(model_list[[1]], 'glmerMod')
		}
	} else {
		if(is.null(exponentiate)){
			exponentiate <- inherits(model, 'coxph') ||
				(inherits(model, 'glm') && model$family$link == 'logit') ||
				inherits(model, 'glmerMod')
		}
	}

	sample_size_print <- model %>% insight::n_obs()

	if(exponentiate){
		trans <- exp
	} else{
		trans <- I
	}

	stopifnot(is.list(panels))

	remove_backticks <- function(x){
		gsub('^`|`$|\\\\(?=`)|`(?=:)|(?<=:)`', '', x, perl = TRUE)
	}

	make_forest_terms <- function(model){
		if(inherits(model, 'lmerMod') | inherits(model, 'glmerMod')){
			tidy_model <- model %>%
				parameters::model_parameters(effects = 'fixed') %>%
				parameters::standardize_names(style = 'broom') %>%
				as_tibble()

			term_labels <- model %>% terms() %>% attr('term.labels')
			variables <- model %>% insight::get_predictors() %>% names()
			classes <- model %>%
				get_predictors() %>%
				names() %>%
				map_chr(
					~(
						model %>%
							insight::get_data() %>%
							pull(.x) %>%
							class()
					),
					.progress = TRUE
				) %>%
				set_names(variables)
		} else {
			tidy_model <- broom::tidy(model, conf.int = TRUE)
			term_labels <- attr(model$terms, 'term.labels')
			variables <- names(attr(model$terms, 'dataClasses'))[-1]
			classes <- attr(model$terms, 'dataClasses')[-1]
		}

		data <- stats::model.frame(model)

		forest_terms <- tibble::tibble(
			term_label = term_labels,
			variable = remove_backticks(term_label)
		) %>%
			inner_join(tibble::tibble(
				variable = variables,
				class = classes
			),
			by = 'variable')

		forest_labels <- tibble::tibble(
			variable = model %>% insight::find_predictors() %>% pluck(1),
			label = map_chr(
				.x = variable,
				.f = ~(
					if(model %>% insight::get_data() %>% pull(.x) %>% var_label() %>% is_empty() %>% `!`){
						model %>%
							insight::get_data() %>%
							pull(.x) %>%
							var_label()
					} else {
						.x
					}
				),
				.progress = TRUE
			) %>%
				coalesce(variable)
		)

		create_term_data <- function(term_row){
			if(!is.na(term_row$class)){
				var <- term_row$variable
				if(term_row$class %in% c('factor', 'character')){
					tab <- table(data[, var])
					if(!any(paste0(term_row$term_label, names(tab)) %in% tidy_model$term)){
						# Filter out terms not in final model summary (e.g. strata)
						out <- tibble::tibble(variable = NA)
					} else {
						out <- data.frame(
							term_row,
							level = names(tab),
							level_no = 1:length(tab),
							n = as.integer(tab),
							stringsAsFactors = FALSE
						)
						if(factor_separate_line){
							out <- bind_rows(tibble::as_tibble(term_row), out)
						}
						if(inherits(model, 'coxph')){
							data_event <- bind_cols(data[, -1, drop = FALSE],
																			.event_time = data[, 1][, ncol(data[, 1]) -
																																1],
																			.event_status = data[, 1][, ncol(data[, 1])])
							event_detail_tab <- data_event %>%
								group_by(!!as.name(var)) %>%
								summarise(
									person_time = sum(.event_time),
									n_events = sum(.event_status)
								)
							colnames(event_detail_tab)[1] <- 'level'
							event_detail_tab$level <-
								as.character(event_detail_tab$level)
							out <-
								out %>% left_join(event_detail_tab, by = 'level')
						}
					}
				} else {
					out <- data.frame(
						term_row,
						level = NA,
						level_no = NA,
						n = sum(!is.na(data[, var])),
						stringsAsFactors = FALSE
					)
					if(term_row$class == 'logical'){
						out$term_label <- paste0(term_row$term_label, 'TRUE')
					}
				}
			} else {
				out <-
					data.frame(
						term_row,
						level = NA,
						level_no = NA,
						n = NA,
						stringsAsFactors = FALSE
					)
			}
			out
		}
		forest_terms <- forest_terms %>%
			rowwise() %>%
			do(create_term_data(.)) %>%
			ungroup() %>%
			filter(!is.na(variable)) %>%
			mutate(term = paste0(term_label, replace(level, is.na(level), ''))) %>%
			left_join(tidy_model, by = 'term') %>%
			mutate(
				reference = ifelse(is.na(level_no), FALSE, level_no == 1),
				estimate = ifelse(reference, 0, estimate),
				variable = ifelse(is.na(variable), remove_backticks(term), variable)
			) %>%
			mutate(variable = ifelse(
				is.na(level_no) |
					(level_no == 1 & !factor_separate_line),
				variable,
				NA
			)) %>%
			left_join(forest_labels,
								by = 'variable') %>%
			mutate(variable = coalesce(label, variable))
		if(!is.null(covariates)){
			forest_terms <- filter(forest_terms, term_label %in% covariates)
		}

		forest_terms
	}

	if(!is.null(model_list)){
		forest_terms <- lapply(seq_along(model_list), function(i){
			make_forest_terms(model_list[[i]]) %>%
				mutate(model_name = model_names[i])
		}) %>%
			bind_rows()
		if(merge_models){
			forest_terms$model_name <- NULL
		}
	} else {
		forest_terms <- make_forest_terms(model)
	}

	# #use_exp <- grepl('exp', deparse(trans))
	if(!is.null(limits)){
		forest_terms <- forest_terms %>%
			mutate(
				arrow_tag.l = limits[1],
				arrow_tag.r = limits[2],
				arrow_tag.l = ifelse(conf.low < .data$arrow_tag.l, TRUE, FALSE),
				arrow_tag.r = ifelse(conf.high > .data$arrow_tag.r, TRUE, FALSE)
			) %>%
			mutate(
				plot_range.low = ifelse(.data$arrow_tag.l, limits[1], conf.low),
				plot_range.high = ifelse(.data$arrow_tag.r, limits[2], conf.high)
			)
	}

	plot_data <- list(
		forest_data = forest_terms,
		mapping = mapping,
		panels = panels,
		trans = trans,
		funcs = funcs,
		format_options = format_options,
		theme = theme,
		limits = limits,
		breaks = breaks,
		recalculate_width = recalculate_width,
		recalculate_height = recalculate_height,
		exclude_infinite_cis = exclude_infinite_cis
	)
	main_plot <- do.call('panel_forest_plot', plot_data) +
		theme(axis.text.x = element_text(size = axis_text_size, color = 'black'))

	if(return_data){
		list(plot_data = plot_data, plot = main_plot)
	} else {
		main_plot
	}
}
