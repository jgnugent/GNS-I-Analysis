jgn_cut_dataset <- function(base_recipe){
	vars_to_split <- base_recipe %>%
		step_select(all_numeric_predictors()) %>%
		prep() %>%
		juice() %>%
		names()

	split_data <- base_recipe %>%
		step_select(all_outcomes(), all_numeric_predictors()) %>%
		step_discretize_xgb(all_numeric_predictors(), outcome = (base_recipe$var_info %>% filter(role == 'outcome'))$variable) %>%
		step_rm(all_outcomes()) %>%
		prep() %>%
		juice() %>%
		select(where(is.factor))

	split_names <- split_data %>% names()

	split_data_rename <- split_data %>%
		copy_labels_from(base_recipe$template) %>%
		rename_all(~ paste0(., '_cut'))

	vars_to_split_cart <- setdiff(vars_to_split, split_names)

	split_data_cart <- base_recipe %>%
		step_select(all_outcomes(), all_numeric_predictors()) %>%
		step_discretize_cart(all_of(vars_to_split_cart), outcome = (base_recipe$var_info %>% filter(role == 'outcome'))$variable) %>%
		step_rm(all_outcomes()) %>%
		prep() %>%
		juice() %>%
		select(where(is.factor))

	split_data_cart_names <- split_data_cart %>% names()

	split_data_cart_rename <- split_data_cart %>%
		copy_labels_from(base_recipe$template) %>%
		rename_all(~ paste0(., '_cart'))

	split_names_all <- c(split_names, split_data_cart_names)

	split_data_rename_all <- bind_cols(
		split_data_rename,
		split_data_cart_rename
	)

	for(i in 1:ncol(split_data_rename_all)){
		var_label(split_data_rename_all[i]) <- paste0(var_label(split_data_rename_all[i]), ' (Categorical)')
	}

	split_data_out <- bind_cols(
		base_recipe$template,
		split_data_rename_all
	) %>% reduce(
		.x = c(split_data_rename_all %>% names(), split_names_all) %>% split(., 1:length(split_names_all)) %>% unname(),
		.f = ~ relocate(.x, .y[1], .after = .y[2]),
		.init = .
	)

	return(split_data_out)
}

output_to_stata <- function(x, mutate_vars = NULL, location = '~/Library/CloudStorage/OneDrive-OregonHealth&ScienceUniversity/Datasets/'){
	if(!is.data.frame(x)){
		stata_output <- get(x)
		output_name <- x
	} else {
		stata_output <- x
		output_name <- deparse(substitute(x))
	}

	if(!is.null(mutate_vars)){
		stata_output <- stata_output %>%
			mutate_at(mutate_vars, function(x){x %>% as.numeric() %>% -1})
	}
	names(stata_output) <- names(stata_output) %>% stringr::str_trunc(width = 32, ellipsis = '')
	haven::write_dta(stata_output, paste0(location, output_name,'.dta'))
}

purposeful_step_4 <- function(preliminary_main_effects, excluded_covariates, data = NULL){
	excluded_covariates_n <- length(excluded_covariates)

	for (i in 1:excluded_covariates_n){
		excluded_variable = excluded_covariates[i]
		full_model = glm(as.formula(
			paste0(formula(preliminary_main_effects)[2],'~',formula(preliminary_main_effects)[3],'+',excluded_variable)
		), family = 'binomial', data = data %>% filter(!is.na(excluded_variable)))

		reduced_model = glm(as.formula(
			paste0(formula(preliminary_main_effects)[2],'~',formula(preliminary_main_effects)[3])
		), family = 'binomial', data = full_model$model)

		step_4_wald <<- rbind(
			step_4_wald,
			full_model %>%
				tidy() %>%
				filter(row_number() > reduced_model %>% tidy() %>% nrow())
		) %>% distinct()

		step_4_excluded_lrt <- anova(
			reduced_model,
			full_model,
			test = 'LRT'
		) %>% tidy()

		step_4_lrt <<- rbind(
			step_4_lrt,
			step_4_excluded_lrt %>%
				filter(!is.na(p.value)) %>%
				mutate(term = excluded_variable) %>%
				relocate(term)
		) %>% distinct()
	}
}

purposeful_step_6 <- function(preliminary_main_effects, data = NULL){
	# Extract variables from model, split into vector
	covariates <- setdiff(
		all.vars(formula(preliminary_main_effects)),
		str_replace_all(formula(preliminary_main_effects)[2] %>% as.character(),'()','')
	)

	# Create all combination of interactions, store as vector
	combinations <- combn(covariates, 2, simplify = FALSE)
	combinations_n <- combinations %>% length()

	interaction_models_lrt <<- tibble()
	interaction_models_wald <<- tibble()

	# Iterate through all possible interactions and print results
	for (i in 1:combinations_n){
		interaction_term <- paste0(combinations[[i]], collapse = '*')

		full_model = glm(as.formula(
			paste0(formula(preliminary_main_effects)[2],'~',formula(preliminary_main_effects)[3],'+',interaction_term)
		), family = 'binomial', data = data)

		interaction_wald <- full_model %>% tidy()

		#interaction_wald %>% printKable(paste0('Wald test for preliminary main effects model with interaction term `',interaction_term,'`')) %>% print()

		interaction_models_wald <<- rbind(
			interaction_models_wald,
			interaction_wald %>%
				filter(row_number() == n())
		) %>% distinct()

		reduced_model = glm(as.formula(
			paste0(formula(preliminary_main_effects)[2],'~',formula(preliminary_main_effects)[3])
		), family = 'binomial', data = full_model$model)

		interaction_lrt <- anova(
			reduced_model,
			full_model,
			test = 'LRT'
		) %>% tidy()

		interaction_models_lrt <<- rbind(
			interaction_models_lrt,
			interaction_lrt %>%
				filter(!is.na(p.value)) %>%
				mutate(term = interaction_term) %>%
				relocate(term)
		) %>% distinct()

		#interaction_lrt %>% printKable(paste0('Likelihood ratio test for preliminary main effects model with and without `',interaction_term,'`')) %>% print()
	}
}

jgn_median_odds_ratio <- function(model, random_effect, round_digits = 2, include_merlo = TRUE, print = TRUE){
	random_effect_data <- ranef(model, condVar = TRUE)
	random_effect_data_subset <- random_effect_data %>% pluck(random_effect)
	estimates <- as.numeric(unlist(random_effect_data_subset))
	variances <- as.numeric(unlist(attr(random_effect_data_subset, 'postVar')))

	# Prepare boostrap by creating empty output collection
	mor_boot <- c()

	# Iterate over replicates
	for(i in 1:1000){
		# Create a vector of area random effects from normal
		vector <- rnorm(
			n = length(estimates),
			mean = estimates,
			sd = sqrt(variances)
		)
		# Create data frame with all possible pairs
		pairs <- combn(vector, 2)

		# Estimate median odds ratio and save in output
		mor_boot <- c(mor_boot, median(exp(abs(pairs[1,] - pairs[2,]))))
	}

	variance_correlation_components <- model %>%
		VarCorr() %>%
		as_tibble() %>%
		select(-one_of('var1', 'var2')) %>%
		rename(
			'Group' = grp,
			'Variance' = vcov,
			'Standard Deviation' = sdcor
		)

	mor_table <- tribble(
		~Method, ~MOR, ~ci_lb, ~ci_ub,
		'Merlo', variance_correlation_components %>%
			filter(Group == random_effect) %>%
			pull(Variance) %>%
			as.numeric() %>%
			mor(),
			NA_integer_,
			NA_integer_,
		'Bootstrap',
		mor_boot %>% quantile(0.5) %>% as.numeric(),
		mor_boot %>% quantile(0.025) %>% as.numeric(),
		mor_boot %>% quantile(.975) %>% as.numeric()
	) %>%
		mutate_if(is.numeric, ~sprintf(paste0('%0.', round_digits, 'f'), .x)) %>%
		mutate(
			`Median Odds Ratio (95% CI)` = case_when(
				ci_lb == 'NA' & ci_ub == 'NA' ~ paste0(MOR),
				is.na(ci_lb) & is.na(ci_ub) ~ paste0(MOR),
				.default =  paste0(MOR, ' (', ci_lb, ' – ', ci_ub, ')')
			)
		) %>%
		select(1,5)

	if(!include_merlo){
		mor_table <- mor_table %>%
			filter(Method != 'Merlo')
	}

	if(print){
		mor_table %>%
			print_kable()
	} else {
		mor_table
	}
}

MOR <- function(my.var, digits = 2){
	# From: https://gist.github.com/docsteveharris/264628336fa9f75c6b43
	# via https://stat.ethz.ch/pipermail/r-sig-mixed-models/2008q2/000874.html
	# Calculate the median odds ratio
	# -------------------------------
	# MOR arguments: my.var = variance associated with level 2 clustering variable
	# digits = number of decimal places to which MOR value will be rounded.

	Median.OR <- round(exp(sqrt(2*my.var)*qnorm(.75)), digits)
	paste("Median Odds-Ratio (MOR) = ", Median.OR)  }

IOR <- function(my.var, my.coef, my.diff, digits = 2){
	# IOR arguments: my.var = variance associated with level 2 clustering variable
	# my.coef = fixed effect coefficient associated with a level 2 covariate
	# my.diff = difference between 2 different possible values on the level
	#           2 covariate associated with my.coef
	# digits = number of decimal places to which MOR value will be rounded.

	IOR.LL <- round(exp(my.coef*my.diff + sqrt(2*my.var)*qnorm(.10)), digits)
	IOR.UL <- round(exp(my.coef*my.diff + sqrt(2*my.var)*qnorm(.90)), digits)
	print("80% Interval Odds Ratio lower & upper limits (IOR.LL & IOR.UL)")
	cbind(my.var, my.coef, my.diff, IOR.LL, IOR.UL)
}

jgn_kappa <- function(data, include_weighted = FALSE, include_latex = FALSE, round_digits = 3, kappa_weighting = 'squared'){
	irr_data <- irr::kappa2(data, weight = 'unweighted')
	irr_data_weighted <- irr::kappa2(data, weight = kappa_weighting)

	output <- psych::cohen.kappa(data) %>%
		tidy() %>%
		mutate(
			method = case_when(
				type == 'unweighted' ~ irr_data$method,
				TRUE ~ irr_data_weighted$method
			),
			subjects = irr_data$subjects,
			raters = irr_data$raters,
			ci_display = paste0(round(conf.low, digits = ), ' - ', round(conf.high, digits = round_digits)),
			estimate_ci = paste0(round(estimate, digits = round_digits), ' (', ci_display, ')'),
			p.value = case_when(
				type == 'unweighted' ~ irr_data$p.value,
				TRUE ~ irr_data_weighted$p.value
			)
		) %>%
		select(method, subjects, raters, estimate_ci, p.value) %>%
		rename(
			`Method` = method,
			`# of Subjects` = subjects,
			`# of Raters` = raters
		)

	if(include_latex == TRUE){
		output <- output %>%
			mutate(
				p.value = p.value %>% scales::pvalue(accuracy = 0.0001)
			) %>%
			rename(
				`Cohen's $\\kappa$ (95% CI)` = estimate_ci,
				`$p$-value` = p.value
			)
	} else {
		output <- output %>%
			rename(
				`Cohen's Kappa (95% CI)` = estimate_ci,
				`p-value` = p.value
			)
	}

	if(include_weighted == FALSE){
		output <- output %>%
			filter(Method == 'Cohen\'s Kappa for 2 Raters (Weights: unweighted)') %>%
			mutate(
				Method = 'Cohen\'s Kappa for 2 Raters'
			)
	}

	return(output)
}

jgn_icc <- function(data, include_latex = FALSE, type = '2', round_digits = 3){
	type_filter <- paste0('ICC', type)

	irr_data <- irr::icc(data, model = 'twoway', type = 'agreement')

	psych_data <- psych::ICC(data)
	psych_results <- psych_data$results %>%
		filter(type == type_filter)

	if(type == '1'){
		method_display = 'Single Score Intraclass Correlation (One-way random-effects model)'
	}

	if(type == '2'){
		method_display = 'Single Score Intraclass Correlation (Two-way random-effects model)'
	}

	if(type == '3'){
		method_display = 'Single Score Intraclass Correlation (Two-way mixed-effects model)'
	}

	if(type == '1k'){
		method_display = 'Average Score Intraclass Correlation (One-way random-effects model)'
	}

	if(type == '2k'){
		method_display = 'Average Score Intraclass Correlation (Two-way random-effects model)'
	}

	if(type == '3k'){
		method_display = 'Average Score Intraclass Correlation (Two-way mixed-effects model)'
	}

	output <- tribble(
		~method, ~subjects, ~raters, ~estimate_ci, ~p.value,
		'', '', '', '', ''
	) %>%
		mutate(
			method = method_display,
			subjects = irr_data$subjects,
			raters = psych_data$n.judge,
			`F` = psych_results$`F`,
			df1 = psych_results$df1,
			df2 = psych_results$df2,
			ci_display = paste0(round(psych_results$`lower bound`, digits = round_digits), ' - ', round(psych_results$`upper bound`, digits = round_digits)),
			estimate_ci = paste0(round(psych_results$ICC, digits = round_digits), ' (', ci_display, ')'),
			p.value = psych_results$p
		) %>%
		select(method, subjects, raters, estimate_ci, p.value) %>%
		rename(
			`Method` = method,
			`# of Subjects` = subjects,
			`# of Raters` = raters,
			`ICC (95% CI)` = estimate_ci
		)

	if(include_latex == TRUE){
		output <- output %>%
			mutate(
				p.value = p.value %>% scales::pvalue(accuracy = 0.0001)
			) %>%
			rename(
				`$p$-value` = p.value
			)
	} else {
		output <- output %>%
			rename(
				`p-value` = p.value
			)
	}

	return(output)
}

extract_r_data_object <- function(file, object){
	# From: https://stackoverflow.com/questions/65964064/programmatically-extract-an-object-from-collection-of-rdata-files/65964065#65964065
	# Function for extracting an object from a .RData file created by R's save() command
	# Inputs: RData file, object name
	env <- new.env()
	load(file = file, envir = env)
	get(object, envir = env, inherits = FALSE) %>%
		return()
}

jgn_list_loaded_packages <- function(){
	require(dplyr, warn.conflicts = FALSE, quietly = TRUE)
	require(tibble, warn.conflicts = FALSE, quietly = TRUE)

	(.packages()) %>%
		sort() %>%
		as_tibble() %>%
		set_names('Loaded Packages') %>%
		jgntools::print_kable()
}

print_session_info <- function(){
	# From: https://themockup.blog/posts/2022-04-18-session-info/

	pkg_session <- sessioninfo::session_info(pkgs = 'attached')

	# get the quarto version
	quarto_version <- system("quarto --version", intern = TRUE)

	# inject the quarto info
	pkg_session$platform$quarto <- paste(
		system("quarto --version", intern = TRUE),
		"@",
		quarto::quarto_path()
	)

	# print it out
	pkg_session %>%
		print()
}

copy_yml <- function(){
	require(dplyr, warn.conflicts = FALSE, quietly = TRUE)

	base_file <- readLines('~/GitHub/quarto/_headers.yml')

	base_edits <- base_file %>%
		gsub('~', normalizePath('~/'), .)

	base_edits %>%
		writeLines(., '~/GitHub/_headers.yml')

	base_edits %>%
		gsub('echo: true', 'echo: false', .) %>%
		gsub('code-copy: true', '# code-copy: true', .) %>%
		gsub('code-fold: true', '# code-fold: true', .) %>%
		gsub('code-line-numbers: true', '# code-line-numbers: true', .) %>%
		gsub('code-overflow: wrap', '# code-overflow: wrap', .) %>%
		gsub('code-tools: true', '# code-tools: true', .) %>%
		writeLines(., '~/GitHub/_headers_nocode.yml')

	base_edits %>%
		gsub('embed-resources: true', 'embed-resources: false', .) %>%
		gsub('# fig-dpi: 300', 'fig-dpi: 300', .) %>%
		gsub('# fig-format: pdf', 'fig-format: pdf', .) %>%
		gsub('# knitr:', 'knitr:', .) %>%
		gsub('#   opts_chunk:', '   opts_chunk:', .) %>%
		gsub('#     dev: quartz_pdf', '     dev: quartz_pdf', .) %>%
		gsub('#     dpi: 300', '     dpi: 300', .) %>%
		writeLines(., '~/GitHub/_headers_pdf.yml')

	base_edits %>%
		gsub('embed-resources: true', 'embed-resources: false', .) %>%
		gsub('# fig-dpi: 300', 'fig-dpi: 300', .) %>%
		gsub('# knitr:', 'knitr:', .) %>%
		gsub('#   opts_chunk:', '   opts_chunk:', .) %>%
		gsub('#     dev: quartz_pdf', '     dev: quartz_tiff', .) %>%
		gsub('#     dpi: 300', '     dpi: 300', .) %>%
		writeLines(., '~/GitHub/_headers_tiff.yml')

	base_edits %>%
		gsub('# cache: true', ' cache: true', .) %>%
		writeLines(., '~/GitHub/_headers_cache.yml')
}

remove_all_functions <- function(){
	walk(
		ls(envir = globalenv()),
		~(
			if(get(.x) %>% class() %>% pluck(1) == 'function'){
				rm(list = .x, envir = globalenv())
			}
		)
	)
}

print_output_file_name <- function(additional = NULL, adorn_date = TRUE){
	if(!rlang::is_empty(additional)){
		paste_string <- paste0('_', additional, '_')
	} else {
		paste_string <- '_'
	}

	output <- rstudioapi::getActiveDocumentContext()$path %>%
		str_extract('([^\\/]+$)') %>%
		str_remove('(.[^.]*$)')

	if(adorn_date){
		output <- output %>%
		paste0(., paste_string, format(Sys.time(), '%m%d%y'))
	}

	return(output)
}
