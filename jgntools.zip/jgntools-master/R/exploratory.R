jgn_missing_values <- function(data, print = TRUE){
	output <- map_df(
		.x = data,
		~(
			tibble(
				Label = var_label(.x),
				Missing = sum(is.na(.x))
			)
		),
		.id = 'Variable'
	)

	if(print){
		output <- output %>%
			print_kable()
	}

	return(output)
}

jgn_import_excel_labelled <- function(data, print = FALSE){
	if(print){
		data %>%
			map_chr(
				.x = names(.),
				.f = ~paste0(
					janitor::make_clean_names(.x), ' = \'', .x, '\','
				)
			) %>%
			select(-one_of('Variable')) %>%
			print_kable() %>%
			print()
	} else {
		output <- data %>%
			janitor::clean_names()

		walk(
			data %>% names(),
			~(
				output <<- output %>%
					set_variable_labels(
						!!janitor::make_clean_names(.x) := .x
					)
			)
		)
		return(output)
	}
}

age_sex_adjust <- function(data_var, group_var, age_var, sex_var, event_var, time_var){
  # From: https://www.r-bloggers.com/2021/11/age-and-sex-adjusted-incidence-rates/
  group_var <- deparse(substitute(group_var))
  age_var <- deparse(substitute(age_var))
  sex_var <- deparse(substitute(sex_var))
  event_var <- deparse(substitute(event_var))
  time_var <- deparse(substitute(time_var))

  group_levels <- levels({{data_var}}[[{{group_var}}]])
  offset <- log(as.numeric(data_var[[time_var]] / 365.25 / 100))
  data_trans <- transform(data_var, time_var = 36525) # To get IR since offset is specified as days/362.25/100
  formula <- formula(paste0(event_var, " ~ ", group_var, " * ", "I(", age_var, "^2)", " + ", sex_var))

  poisson_fit <- glm(
    formula = formula,
    offset = offset,
    data = data_var,
    family = poisson
  )

  std_fit <- stdGlm(poisson_fit, data = data_trans, X = group_var)

  std_sum <-summary(std_fit, CI.type = "log") # To correct CI use type = "log", otherwise possible with negative values

  std_sum[["est.table"]] %>%
    as_tibble(rownames = group_var) %>%
    transmute({{group_var}} := group_levels,
              IR = Estimate,
              lower = `lower 0.95`,
              upper = `upper 0.95`)
}

jgn_walk_histogram <- function(data){
  walk(
    data %>%
      select_if(is.numeric) %>%
      select(-one_of('pt_id', 'mrn')),
    ~(
      ggplot(
        data = data,
        aes(x = .x,),
        color = 'black'
      ) +
        geom_density(alpha = 0.75, fill = ggsci::pal_d3()(3)[3]) +
        theme_jgn() +
        labs(x = var_label(.x),
             y = 'Density') +
        scale_x_continuous(n.breaks = 10)
    ) %>% print(),
    .progress = TRUE
  )
}

jgn_walk_histogram_stratified <- function(data, strata_var){
  strata_var_name <- deparse(substitute(strata_var))
  strata_label <- data %>% pull(strata_var_name) %>% var_label()

  walk(
    data %>%
      select_if(is.numeric) %>%
      select(-one_of('pt_id', 'mrn')),
    ~(
      ggplot(
        data = data,
        aes(
          x = .x,
          color = get(strata_var_name),
          fill = get(strata_var_name)
        ),
      ) +
        geom_density(alpha = 0.75) +
        theme_jgn() +
        labs(
          x = var_label(.x),
          y = 'Density',
          color = strata_label,
          fill = strata_label
        ) +
        scale_x_continuous(n.breaks = 10) +
        lemon::facet_rep_grid(get(strata_var_name) ~ ., repeat.tick.labels = TRUE) +
        ggsci::scale_fill_d3() +
        ggsci::scale_color_d3()
    ) %>% print(),
    .progress = TRUE
  )
}

jgn_walk_qq <- function(data){
  walk(
    data %>%
      select_if(is.numeric) %>%
      select(-one_of('pt_id', 'mrn')),
    ~(
      ggplot(
        data = data,
        aes(sample = .x)
      ) +
        qqplotr::geom_qq_band(bandType = 'ks', mapping = aes(fill = 'KS'), alpha = 0.5) +
        qqplotr::geom_qq_band(bandType = 'ts', mapping = aes(fill = 'TS'), alpha = 0.5) +
        qqplotr::geom_qq_band(bandType = 'pointwise', mapping = aes(fill = 'Normal'), alpha = 0.5) +
        qqplotr::geom_qq_band(bandType = 'boot', mapping = aes(fill = 'Bootstrap'), alpha = 0.5) +
        qqplotr::geom_qq_band(bandType = 'ell', mapping = aes(fill = 'Ell'), alpha = 0.5) +
        qqplotr::stat_qq_point() +
        qqplotr::stat_qq_line() +
        theme_jgn() +
        labs(
          x = paste0(var_label(.x), ' Theoretical Quantiles'),
          y = 'Sample Quantiles',
          fill = 'Bandtype'
        ) +
        scale_x_continuous(n.breaks = 6) +
        scale_y_continuous(n.breaks = 6) +
        ggsci::scale_fill_d3()
    ) %>% print(),
    .progress = TRUE
  )
}

jgn_walk_qq_stratified <- function(data, strata_var){
  strata_var_name <- deparse(substitute(strata_var))

  walk(
    data %>%
      select_if(is.numeric) %>%
      select(-one_of('pt_id', 'mrn')),
    ~(
      ggplot(
        data = data,
        aes(sample = .x)
      ) +
        qqplotr::geom_qq_band(bandType = 'ks', mapping = aes(fill = 'KS'), alpha = 0.5) +
        qqplotr::geom_qq_band(bandType = 'ts', mapping = aes(fill = 'TS'), alpha = 0.5) +
        qqplotr::geom_qq_band(bandType = 'pointwise', mapping = aes(fill = 'Normal'), alpha = 0.5) +
        qqplotr::geom_qq_band(bandType = 'boot', mapping = aes(fill = 'Bootstrap'), alpha = 0.5) +
        qqplotr::geom_qq_band(bandType = 'ell', mapping = aes(fill = 'Ell'), alpha = 0.5) +
        qqplotr::stat_qq_point() +
        qqplotr::stat_qq_line() +
        theme_jgn() +
        labs(
          x = paste0(var_label(.x), ' Theoretical Quantiles'),
          y = 'Sample Quantiles',
          fill = 'Bandtype'
        ) +
        scale_x_continuous(n.breaks = 6) +
        scale_y_continuous(n.breaks = 6) +
        ggsci::scale_fill_d3() +
        lemon::facet_rep_grid(~get(strata_var_name), scales = 'free', repeat.tick.labels = 'y')
    ) %>% print(),
    .progress = TRUE
  )
}

jgn_walk_factor_2x2 <- function(data){
  # From: https://community.rstudio.com/t/print-variable-name-instead-of-value/114287
  iwalk(
    data %>%
      select_if(is.factor),
    ~(tabyl(.x) %>% rename(!!.y := 1)) %>%
      adorn_totals() %>%
      adorn_pct_formatting() %>%
      print_kable() %>%
    	tab_spanner(label = html('<strong><u>', var_label(.x), '</u></strong>'), columns = everything()) %>%
    	tab_style(
    		style = cell_text(decorate = 'underline'),
    		locations = cells_body(columns = 1)
    	) %>%
    	tab_style(
    		style = cell_text(weight = 'bold'),
    		locations = cells_body(
    			rows = everything() %>% length()
    		)
    	) %>%
      print(),
    .progress = TRUE
  )
}

jgn_walk_factor_RxC <- function(data, strata_var){
  # From: https://stackoverflow.com/questions/58771054/using-strings-within-janitor-tabyl-top-level
  # And: https://github.com/haozhu233/kableExtra/issues/415

  strata_var_name <- deparse(substitute(strata_var))
  strata <- data %>% pull(strata_var_name)

  iwalk(
    data %>%
      select(where(is.factor), -one_of(strata_var_name)),
    ~(
      expr(
        data %>%
          tabyl(!!!syms(c(.y, eval(strata_var_name)))) %>%
        	adorn_totals(where = c('row', 'col')) %>%
        	adorn_percentages(denominator = 'col') %>%
        	adorn_pct_formatting() %>%
        	adorn_ns(position = 'front') %>%
        	print_kable() %>%
        	tab_spanner(label = html('<strong><u>', var_label(strata), '</u></strong>'), columns = c(levels(strata), 'Total')) %>%
        	tab_spanner(label = html('<strong><u>', var_label(.x), '</u></strong>'), columns = 1) %>%
        	tab_style(
        		style = cell_text(decorate = 'underline'),
        		locations = cells_body(columns = 1)
        	) %>%
        	tab_style(
        		style = cell_text(weight = 'bold'),
        		locations = cells_body(
        			rows = everything() %>% length()
        		)
        	)
      ) %>%
        rlang::eval_tidy() %>%
        print()
    ),
    .progress = TRUE
  )
}

jgn_variable_labels <- function(data, print = TRUE){
	output <- map_df(
		.x = data,
		~(tibble(Label = var_label(.x))),
		.id = 'Variable'
	)

	if(print){
		output <- output %>%
			print_kable()
	}

	return(output)
}

jgn_variables_lacking_labels <- function(data, print = TRUE){
	output <- data %>%
		select(where(~is.null(attributes(.)$label))) %>%
		names() %>%
		as_tibble()

	if(print){
		if(!plyr::empty(output)){
			output <- output %>%
				print_kable()
		} else {
			output <- NA
		}
	}

	return(output)
}

jgn_variable_types <- function(data, print = TRUE){
	output <- map_df(
		.x = data,
		~tibble(
			Label = var_label(.x),
			Class = class(.x),
			Type = typeof(.x)
		),
		.id = 'Variable'
	)

	if(print){
		output <- output %>%
			print_kable()
	}

	return(output)
}

format_ohsu_mrn <- function(data){
	data %>%
		str_pad(width = 8, side = 'left', pad = '0')
}

jgn_walk_gladder <- function(data){
	walk(
		data %>%
			select_if(is.numeric) %>%
			select(-one_of('pt_id', 'mrn')),
		~(
			.x %>%
				subset(. > 0) %>%
				describedata::gladder() +
				theme_jgn() +
				labs(title = var_label(.x))
		) %>% print(),
		.progress = TRUE
	)
}
